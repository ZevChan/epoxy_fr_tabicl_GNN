#!/usr/bin/env python3
"""Verify and compare tabular representation runs that used identical validation folds."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Aggregate representation ablations only after proving fold identity."
    )
    parser.add_argument(
        "--runs",
        nargs="+",
        required=True,
        help="Representation runs as name=benchmark_output_directory",
    )
    parser.add_argument("--baseline", help="Baseline representation name; default is first run")
    parser.add_argument(
        "--allow-model-selection",
        action="store_true",
        help="Allow each representation to select a different model; this confounds representation effects",
    )
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args()


def parse_runs(values: list[str]) -> list[tuple[str, Path]]:
    runs: list[tuple[str, Path]] = []
    seen: set[str] = set()
    for value in values:
        if "=" not in value:
            raise ValueError(f"Run must use name=directory syntax: {value}")
        name, raw_path = value.split("=", 1)
        name = name.strip()
        if not name or name in seen:
            raise ValueError(f"Representation names must be unique and non-empty: {name!r}")
        path = Path(raw_path).expanduser()
        if not path.is_dir():
            raise FileNotFoundError(path)
        runs.append((name, path))
        seen.add(name)
    return runs


def load_run(name: str, path: Path) -> dict[str, Any]:
    required = {
        "manifest": path / "benchmark_manifest.json",
        "comparison": path / "model_comparison.csv",
        "oof": path / "oof_predictions.csv",
        "folds": path / "fold_assignments.csv",
    }
    missing = [str(file) for file in required.values() if not file.is_file()]
    if missing:
        raise FileNotFoundError(f"Run {name!r} is incomplete: {missing}")
    return {
        "name": name,
        "path": path,
        "manifest": json.loads(required["manifest"].read_text(encoding="utf-8")),
        "comparison": pd.read_csv(required["comparison"]),
        "oof": pd.read_csv(required["oof"]),
        "folds": pd.read_csv(required["folds"]),
    }


def canonical_folds(frame: pd.DataFrame) -> pd.DataFrame:
    keys = [column for column in ["row_position", "original_index", "fold"] if column in frame]
    if keys != ["row_position", "original_index", "fold"]:
        raise KeyError("fold_assignments.csv must contain row_position, original_index, and fold")
    return frame[keys].sort_values("row_position").reset_index(drop=True)


def selected_oof(run: dict[str, Any]) -> pd.DataFrame:
    selected = str(run["manifest"]["selected_model"])
    frame = run["oof"]
    if "model" in frame:
        frame = frame.loc[frame["model"].astype(str) == selected].copy()
    if frame.empty:
        raise ValueError(f"Selected model {selected!r} has no OOF rows in {run['name']}")
    return frame.sort_values("row_position").reset_index(drop=True)


def main() -> int:
    args = parse_args()
    run_specs = parse_runs(args.runs)
    runs = [load_run(name, path) for name, path in run_specs]
    baseline_name = args.baseline or runs[0]["name"]
    by_name = {run["name"]: run for run in runs}
    if baseline_name not in by_name:
        raise ValueError(f"Baseline {baseline_name!r} is not one of {list(by_name)}")
    baseline = by_name[baseline_name]

    comparison_fields = ["target", "task", "rows", "splitter", "group_definition", "folds", "seed"]
    baseline_manifest = baseline["manifest"]
    baseline_folds = canonical_folds(baseline["folds"])
    for run in runs:
        differences = {
            field: (baseline_manifest.get(field), run["manifest"].get(field))
            for field in comparison_fields
            if baseline_manifest.get(field) != run["manifest"].get(field)
        }
        if differences:
            raise ValueError(f"Run {run['name']!r} is not comparable: {differences}")
        if not baseline_folds.equals(canonical_folds(run["folds"])):
            raise ValueError(f"Run {run['name']!r} used different fold assignments")

    comparison_frames: list[pd.DataFrame] = []
    oof_frames: list[pd.DataFrame] = []
    selected_rows: list[dict[str, Any]] = []
    for run in runs:
        comparison = run["comparison"].copy()
        comparison.insert(0, "representation", run["name"])
        comparison_frames.append(comparison)
        oof = run["oof"].copy()
        oof.insert(0, "representation", run["name"])
        oof_frames.append(oof)
        manifest = run["manifest"]
        metric = str(manifest["primary_metric"])
        selected_rows.append(
            {
                "representation": run["name"],
                "selected_model": manifest["selected_model"],
                "primary_metric": metric,
                "pooled_oof_metric": float(manifest["selected_model_oof_metric"]),
                "feature_count": int(manifest["numeric_feature_count"]),
            }
        )
    selected = pd.DataFrame(selected_rows)
    if selected["selected_model"].nunique() != 1 and not args.allow_model_selection:
        raise ValueError(
            "Representations selected different models. For a representation ablation, rerun each "
            "with the same single --models choice, or pass --allow-model-selection and report the confounding."
        )
    baseline_metric_name = str(baseline_manifest["primary_metric"])
    if selected["primary_metric"].nunique() != 1:
        raise ValueError("Runs selected different primary metrics and cannot be differenced directly")
    baseline_metric = float(
        selected.loc[selected["representation"] == baseline_name, "pooled_oof_metric"].iloc[0]
    )
    selected["conditional_information_gain_vs_baseline"] = (
        selected["pooled_oof_metric"] - baseline_metric
    )

    baseline_oof = selected_oof(baseline)
    task = str(baseline_manifest["task"])
    paired_frames: list[pd.DataFrame] = []
    for run in runs:
        if run["name"] == baseline_name:
            continue
        candidate = selected_oof(run)
        keys = ["row_position", "original_index", "fold"]
        merged = baseline_oof[keys + ["observed", "predicted"]].merge(
            candidate[keys + ["observed", "predicted"]],
            on=keys,
            suffixes=("_baseline", "_candidate"),
            validate="one_to_one",
        )
        if len(merged) != len(baseline_oof):
            raise ValueError(f"Run {run['name']!r} does not contain the same OOF rows")
        if not np.array_equal(
            merged["observed_baseline"].astype(str), merged["observed_candidate"].astype(str)
        ):
            raise ValueError(f"Run {run['name']!r} contains different observed targets")
        merged.insert(0, "candidate_representation", run["name"])
        merged.insert(0, "baseline_representation", baseline_name)
        if task == "regression":
            observed = pd.to_numeric(merged["observed_baseline"], errors="raise")
            base_error = (observed - pd.to_numeric(merged["predicted_baseline"])).abs()
            candidate_error = (observed - pd.to_numeric(merged["predicted_candidate"])).abs()
            merged["absolute_error_improvement"] = base_error - candidate_error
        else:
            base_correct = merged["observed_baseline"].astype(str) == merged["predicted_baseline"].astype(str)
            candidate_correct = merged["observed_baseline"].astype(str) == merged["predicted_candidate"].astype(str)
            merged["correctness_improvement"] = candidate_correct.astype(int) - base_correct.astype(int)
        paired_frames.append(merged)

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    pd.concat(comparison_frames, ignore_index=True).to_csv(
        output_dir / "representation_comparison.csv", index=False
    )
    pd.concat(oof_frames, ignore_index=True).to_csv(
        output_dir / "representation_oof_predictions.csv", index=False
    )
    selected.to_csv(output_dir / "representation_selected_summary.csv", index=False)
    if paired_frames:
        pd.concat(paired_frames, ignore_index=True).to_csv(
            output_dir / "paired_representation_differences.csv", index=False
        )
    summary = {
        "baseline": baseline_name,
        "representations": [run["name"] for run in runs],
        "task": task,
        "primary_metric": baseline_metric_name,
        "fold_identity_verified": True,
        "same_selected_model": bool(selected["selected_model"].nunique() == 1),
        "model_selection_allowed": bool(args.allow_model_selection),
        "warning": (
            "Metric differences are conditional on the shared rows, folds, preprocessing, models, "
            "and feature definitions; they do not establish causal importance."
        ),
    }
    (output_dir / "representation_comparison_manifest.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Artifacts written to {output_dir}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise

#!/usr/bin/env python3
"""Derive compact multi-stage thermal-history features from paired temperature/time columns."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Add maximum temperature, total time, and the discrete thermal-history integral "
            "sum(T_i * t_i) to a tabular dataset."
        )
    )
    parser.add_argument("--input", required=True, help="Input CSV/TSV/XLS/XLSX")
    parser.add_argument("--output", required=True, help="Output CSV/TSV/XLSX")
    parser.add_argument("--temperature-cols", nargs="+", required=True)
    parser.add_argument("--time-cols", nargs="+", required=True)
    parser.add_argument(
        "--missing-policy",
        choices=["strict", "ignore-incomplete"],
        default="strict",
        help="Reject incomplete stage pairs or ignore those stages row by row",
    )
    parser.add_argument("--prefix", default="process_", help="Prefix for the three generated columns")
    parser.add_argument("--temperature-unit", default="degC")
    parser.add_argument("--time-unit", default="h")
    parser.add_argument("--sheet", default=0)
    parser.add_argument("--manifest", help="Default: process_feature_manifest.json beside output")
    return parser.parse_args()


def normalize_list(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        result.extend(part.strip() for part in value.split(",") if part.strip())
    return result


def read_table(path: Path, sheet: str | int = 0) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    if suffix in {".xls", ".xlsx", ".xlsm"}:
        parsed_sheet: str | int = int(sheet) if str(sheet).isdigit() else sheet
        return pd.read_excel(path, sheet_name=parsed_sheet)
    raise ValueError(f"Unsupported input format: {suffix}")


def write_table(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    if suffix == ".csv":
        frame.to_csv(path, index=False)
        return
    if suffix in {".tsv", ".txt"}:
        frame.to_csv(path, sep="\t", index=False)
        return
    if suffix in {".xlsx", ".xls"}:
        frame.to_excel(path, index=False)
        return
    raise ValueError(f"Unsupported output format: {suffix}")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not np.isfinite(value) else float(value)
    return value


def main() -> int:
    args = parse_args()
    input_path = Path(args.input).expanduser()
    output_path = Path(args.output).expanduser()
    if not input_path.is_file():
        raise FileNotFoundError(input_path)
    temperature_cols = normalize_list(args.temperature_cols)
    time_cols = normalize_list(args.time_cols)
    if len(temperature_cols) != len(time_cols):
        raise ValueError("--temperature-cols and --time-cols must contain the same number of stages")
    if not temperature_cols:
        raise ValueError("At least one stage is required")

    frame = read_table(input_path, args.sheet)
    required = temperature_cols + time_cols
    missing = [column for column in required if column not in frame]
    if missing:
        raise KeyError(f"Stage columns not found: {missing}")
    temperatures = frame[temperature_cols].apply(pd.to_numeric, errors="coerce").to_numpy(float)
    times = frame[time_cols].apply(pd.to_numeric, errors="coerce").to_numpy(float)
    incomplete = np.isfinite(temperatures) ^ np.isfinite(times)
    if args.missing_policy == "strict" and incomplete.any():
        positions = np.argwhere(incomplete)[:10]
        examples = [
            {"row": int(row), "stage": int(stage + 1)} for row, stage in positions
        ]
        raise ValueError(f"Incomplete temperature/time stage pairs found: {examples}")
    valid = np.isfinite(temperatures) & np.isfinite(times)
    if (times[valid] < 0).any():
        raise ValueError("Negative stage durations are not allowed")

    masked_temperature = np.where(valid, temperatures, np.nan)
    maximum_temperature = np.max(
        np.where(valid, temperatures, -np.inf), axis=1
    )
    masked_time = np.where(valid, times, np.nan)
    any_stage = valid.any(axis=1)
    with np.errstate(all="ignore"):
        total_time = np.nansum(masked_time, axis=1)
        thermal_integral = np.nansum(masked_temperature * masked_time, axis=1)
    maximum_temperature[~any_stage] = np.nan
    total_time[~any_stage] = np.nan
    thermal_integral[~any_stage] = np.nan

    generated = {
        f"{args.prefix}T_max": maximum_temperature,
        f"{args.prefix}t_total": total_time,
        f"{args.prefix}Q_thermal": thermal_integral,
    }
    collisions = [column for column in generated if column in frame]
    if collisions:
        raise ValueError(f"Generated columns already exist: {collisions}")
    for column, values in generated.items():
        frame[column] = values
    write_table(frame, output_path)

    manifest_path = (
        Path(args.manifest).expanduser()
        if args.manifest
        else output_path.parent / "process_feature_manifest.json"
    )
    manifest = {
        "input": str(input_path.resolve()),
        "input_sha256": sha256_file(input_path),
        "output": str(output_path.resolve()),
        "rows": len(frame),
        "temperature_columns": temperature_cols,
        "time_columns": time_cols,
        "temperature_unit": args.temperature_unit,
        "time_unit": args.time_unit,
        "missing_policy": args.missing_policy,
        "generated_columns": list(generated),
        "formulae": {
            f"{args.prefix}T_max": "max(T_i) across valid stages",
            f"{args.prefix}t_total": "sum(t_i) across valid stages",
            f"{args.prefix}Q_thermal": "sum(T_i * t_i) across valid stages",
        },
        "rows_without_any_valid_stage": int((~any_stage).sum()),
        "incomplete_stage_pairs_ignored": int(incomplete.sum()),
        "versions": {"python": platform.python_version(), "pandas": pd.__version__},
        "warning": (
            "Q_thermal is a compact process summary, not a kinetic cure model; keep raw stages "
            "when pathway effects may matter."
        ),
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(json_safe(manifest), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Wrote {output_path} and {manifest_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise

#!/usr/bin/env python3
"""Apply a saved tabular full-data refit to an external set with optional AD diagnostics."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    roc_auc_score,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Predict an untouched external dataset and flag applicability-domain exposure."
    )
    parser.add_argument("--pipeline", required=True, help="best_pipeline.joblib")
    parser.add_argument("--input", required=True, help="External CSV/TSV/XLS/XLSX")
    parser.add_argument("--output", required=True, help="External prediction CSV")
    parser.add_argument("--id-col", help="Optional row identifier")
    parser.add_argument("--observed-col", help="Optional measured target for external metrics")
    parser.add_argument("--sheet", default=0)
    return parser.parse_args()


def read_table(path: Path, sheet: str | int = 0) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    if suffix in {".xls", ".xlsx", ".xlsm"}:
        parsed_sheet: str | int = int(sheet) if str(sheet).isdigit() else sheet
        return pd.read_excel(path, sheet_name=parsed_sheet)
    raise ValueError(f"Unsupported input format: {suffix}")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def regression_metrics(observed: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    return {
        "r2": float(r2_score(observed, predicted)),
        "rmse": float(mean_squared_error(observed, predicted) ** 0.5),
        "mae": float(mean_absolute_error(observed, predicted)),
    }


def classification_metrics(
    observed: np.ndarray, predicted: np.ndarray, probability: np.ndarray | None
) -> dict[str, float]:
    result = {
        "accuracy": float(accuracy_score(observed, predicted)),
        "balanced_accuracy": float(balanced_accuracy_score(observed, predicted)),
        "f1_macro": float(f1_score(observed, predicted, average="macro")),
    }
    if probability is not None and len(np.unique(observed)) == 2:
        positive = np.unique(observed)[1]
        binary = (observed == positive).astype(int)
        result["roc_auc"] = float(roc_auc_score(binary, probability))
    return result


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    return value


def main() -> int:
    args = parse_args()
    pipeline_path = Path(args.pipeline).expanduser()
    input_path = Path(args.input).expanduser()
    output_path = Path(args.output).expanduser()
    if not pipeline_path.is_file():
        raise FileNotFoundError(pipeline_path)
    if not input_path.is_file():
        raise FileNotFoundError(input_path)
    bundle = joblib.load(pipeline_path)
    required_bundle = ["pipeline", "feature_columns", "task", "model_name"]
    missing_bundle = [key for key in required_bundle if key not in bundle]
    if missing_bundle:
        raise ValueError(f"Pipeline bundle is missing keys: {missing_bundle}")

    frame = read_table(input_path, args.sheet)
    feature_columns = list(bundle["feature_columns"])
    missing_features = [column for column in feature_columns if column not in frame]
    if missing_features:
        raise KeyError(f"External data is missing model features: {missing_features[:20]}")
    if args.id_col and args.id_col not in frame:
        raise KeyError(args.id_col)
    if args.observed_col and args.observed_col not in frame:
        raise KeyError(args.observed_col)
    x = frame[feature_columns].replace([np.inf, -np.inf], np.nan)
    pipeline = bundle["pipeline"]
    raw_prediction = np.asarray(pipeline.predict(x))
    task = str(bundle["task"])
    label_encoder = bundle.get("label_encoder")
    class_labels = bundle.get("class_labels")

    result = pd.DataFrame({"row_position": np.arange(len(frame))})
    if args.id_col:
        result[args.id_col] = frame[args.id_col].to_numpy()
    probability: np.ndarray | None = None
    if task == "classification" and label_encoder is not None:
        encoded = raw_prediction.astype(int)
        result["predicted"] = label_encoder.inverse_transform(encoded)
        if hasattr(pipeline, "predict_proba"):
            probabilities = np.asarray(pipeline.predict_proba(x))
            for class_index, label in enumerate(class_labels or []):
                result[f"probability__{label}"] = probabilities[:, class_index]
            if probabilities.shape[1] == 2:
                probability = probabilities[:, 1]
    else:
        result["predicted"] = raw_prediction

    ad_reference = bundle.get("ad_reference")
    if ad_reference:
        transformed = pipeline[:-1].transform(x)
        distances = ad_reference["neighbors"].kneighbors(
            transformed, n_neighbors=1, return_distance=True
        )[0][:, 0]
        threshold = float(ad_reference["threshold"])
        result["ad_distance"] = distances
        result["ad_threshold"] = threshold
        result["normalized_ad_distance"] = distances / threshold if threshold > 0 else np.nan
        result["in_domain"] = distances <= threshold

    metrics: dict[str, float] | None = None
    if args.observed_col:
        observed = frame[args.observed_col]
        result["observed"] = observed.to_numpy()
        valid = observed.notna().to_numpy()
        if valid.any():
            if task == "regression":
                observed_numeric = pd.to_numeric(observed[valid], errors="coerce").to_numpy(float)
                if not np.isfinite(observed_numeric).all():
                    raise ValueError("Observed external regression labels contain non-numeric values")
                metrics = regression_metrics(observed_numeric, raw_prediction[valid].astype(float))
                result.loc[valid, "absolute_error"] = np.abs(
                    observed_numeric - raw_prediction[valid].astype(float)
                )
            else:
                observed_labels = observed[valid].astype(str).to_numpy()
                predicted_labels = result.loc[valid, "predicted"].astype(str).to_numpy()
                metrics = classification_metrics(
                    observed_labels,
                    predicted_labels,
                    probability[valid] if probability is not None else None,
                )
                result.loc[valid, "correct"] = observed_labels == predicted_labels

    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False)
    manifest = {
        "pipeline": str(pipeline_path.resolve()),
        "pipeline_sha256": sha256_file(pipeline_path),
        "input": str(input_path.resolve()),
        "input_sha256": sha256_file(input_path),
        "output": str(output_path.resolve()),
        "rows": len(frame),
        "task": task,
        "model_name": bundle["model_name"],
        "feature_count": len(feature_columns),
        "observed_column": args.observed_col,
        "external_metrics": metrics,
        "applicability_mode": bundle.get("applicability_mode", "none"),
        "in_domain_rows": (
            int(result["in_domain"].sum()) if "in_domain" in result else None
        ),
        "warning": (
            "External labels must remain untouched by model selection. Out-of-domain predictions "
            "are risk warnings, not evidence of reliable extrapolation."
        ),
    }
    manifest_path = output_path.with_suffix(".manifest.json")
    manifest_path.write_text(
        json.dumps(json_safe(manifest), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Wrote {output_path} and {manifest_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise

#!/usr/bin/env python3
"""Calibrate applicability distance against OOF engineering success and diagnose fine-tuning."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.isotonic import IsotonicRegression


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Convert OOF nearest-neighbor AD distances into risk-coverage and task-specific "
            "engineering-success diagnostics."
        )
    )
    parser.add_argument("--input", required=True, help="OOF predictions with AD columns")
    parser.add_argument("--model", help="Model name when the OOF file contains multiple models")
    parser.add_argument(
        "--task", choices=["auto", "regression", "classification"], default="auto"
    )
    parser.add_argument(
        "--tolerance",
        type=float,
        help="Regression absolute-error tolerance defining engineering success",
    )
    parser.add_argument("--success-probability", type=float, default=0.80)
    parser.add_argument("--coverage-points", type=int, default=10)
    parser.add_argument("--external", help="Optional baseline external prediction CSV")
    parser.add_argument(
        "--fine-tuned-external",
        help="Optional paired external prediction CSV after fine-tuning",
    )
    parser.add_argument("--id-col", help="Identifier for paired external comparisons")
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args()


def infer_task(observed: pd.Series) -> str:
    clean = observed.dropna()
    if not pd.api.types.is_numeric_dtype(clean):
        return "classification"
    unique = clean.nunique()
    threshold = max(10, int(math.sqrt(max(len(clean), 1))))
    return "classification" if unique <= min(20, threshold) else "regression"


def select_model(frame: pd.DataFrame, model: str | None) -> tuple[pd.DataFrame, str | None]:
    if "model" not in frame:
        return frame.copy(), None
    available = frame["model"].dropna().astype(str).unique().tolist()
    if model is None:
        if len(available) != 1:
            raise ValueError(f"--model is required; available models: {available}")
        model = available[0]
    selected = frame.loc[frame["model"].astype(str) == model].copy()
    if selected.empty:
        raise ValueError(f"Model {model!r} not found; available models: {available}")
    return selected, model


def add_diagnostics(frame: pd.DataFrame, task: str, tolerance: float | None) -> pd.DataFrame:
    required = ["observed", "predicted", "ad_distance", "ad_threshold"]
    missing = [column for column in required if column not in frame]
    if missing:
        raise KeyError(f"Prediction file is missing columns: {missing}")
    result = frame.copy()
    distance = pd.to_numeric(result["ad_distance"], errors="coerce")
    threshold = pd.to_numeric(result["ad_threshold"], errors="coerce")
    valid_threshold = threshold > 0
    result["normalized_ad_distance"] = np.where(valid_threshold, distance / threshold, np.nan)
    result["in_domain"] = distance <= threshold
    if task == "regression":
        if tolerance is None or tolerance <= 0:
            raise ValueError("Regression reliability analysis requires --tolerance > 0")
        observed = pd.to_numeric(result["observed"], errors="coerce")
        predicted = pd.to_numeric(result["predicted"], errors="coerce")
        result["absolute_error"] = (observed - predicted).abs()
        result["normalized_error"] = result["absolute_error"] / tolerance
        result["engineering_success"] = result["absolute_error"] <= tolerance
    else:
        observed = result["observed"].astype(str)
        predicted = result["predicted"].astype(str)
        result["correct"] = observed == predicted
        result["normalized_error"] = (~result["correct"]).astype(float)
        result["engineering_success"] = result["correct"]
    return result


def risk_coverage(frame: pd.DataFrame, points: int) -> pd.DataFrame:
    valid = frame.dropna(subset=["normalized_ad_distance", "normalized_error"]).sort_values(
        "normalized_ad_distance"
    )
    if valid.empty:
        raise ValueError("No finite AD distances and errors are available")
    coverages = np.linspace(max(1 / len(valid), 0.1), 1.0, max(points, 2))
    rows: list[dict[str, Any]] = []
    full_risk = float(valid["normalized_error"].mean())
    for requested in coverages:
        retained = max(1, int(math.ceil(requested * len(valid))))
        subset = valid.iloc[:retained]
        rows.append(
            {
                "coverage": retained / len(valid),
                "retained_rows": retained,
                "risk": float(subset["normalized_error"].mean()),
                "full_coverage_risk": full_risk,
                "max_normalized_ad_distance": float(subset["normalized_ad_distance"].max()),
            }
        )
    return pd.DataFrame(rows).drop_duplicates(subset=["retained_rows"])


def reliability_curve(
    frame: pd.DataFrame, success_probability: float
) -> tuple[pd.DataFrame, float | None]:
    valid = frame.dropna(subset=["normalized_ad_distance", "engineering_success"]).copy()
    if valid["normalized_ad_distance"].nunique() < 2:
        raise ValueError("At least two distinct AD distances are required for reliability calibration")
    x = valid["normalized_ad_distance"].to_numpy(float)
    y = valid["engineering_success"].astype(float).to_numpy()
    fit = IsotonicRegression(increasing=False, out_of_bounds="clip").fit(x, y)
    upper = max(float(np.nanmax(x)), 1.0)
    grid = np.linspace(0.0, upper, 201)
    probability = fit.predict(grid)
    eligible = grid[probability >= success_probability]
    boundary = float(eligible.max()) if len(eligible) else None
    return pd.DataFrame(
        {"normalized_ad_distance": grid, "estimated_success_probability": probability}
    ), boundary


def recoverability(
    baseline: pd.DataFrame,
    tuned: pd.DataFrame,
    id_col: str,
    task: str,
    tolerance: float | None,
) -> pd.DataFrame:
    if id_col not in baseline or id_col not in tuned:
        raise KeyError(f"Paired fine-tuning analysis requires {id_col!r} in both files")
    base = add_diagnostics(baseline, task, tolerance)
    after = add_diagnostics(tuned, task, tolerance)
    keep = [id_col, "normalized_ad_distance", "normalized_error"]
    merged = base[keep].merge(after[keep], on=id_col, suffixes=("_baseline", "_fine_tuned"))
    if merged.empty:
        raise ValueError("No paired external rows remain after merging by identifier")
    merged["coverage_gain"] = (
        merged["normalized_ad_distance_baseline"]
        - merged["normalized_ad_distance_fine_tuned"]
    )
    merged["error_reduction"] = (
        merged["normalized_error_baseline"] - merged["normalized_error_fine_tuned"]
    )

    def regime(row: pd.Series) -> str:
        coverage = row["coverage_gain"]
        error = row["error_reduction"]
        if coverage > 0 and error > 0:
            return "coverage-or-calibration-recoverable"
        if coverage > 0 and error <= 0:
            return "representation-limited"
        if coverage <= 0 and error > 0:
            return "calibration-limited"
        return "adverse-or-unresolved-shift"

    merged["recoverability_regime"] = merged.apply(regime, axis=1)
    return merged


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    return value


def main() -> int:
    args = parse_args()
    if not 0 < args.success_probability < 1:
        raise ValueError("--success-probability must be between 0 and 1")
    input_path = Path(args.input).expanduser()
    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(input_path)
    frame, selected_model = select_model(frame, args.model)
    task = infer_task(frame["observed"]) if args.task == "auto" else args.task
    diagnosed = add_diagnostics(frame, task, args.tolerance)
    risk = risk_coverage(diagnosed, args.coverage_points)
    reliability, boundary = reliability_curve(diagnosed, args.success_probability)
    diagnosed.to_csv(output_dir / "ad_oof_diagnostics.csv", index=False)
    risk.to_csv(output_dir / "risk_coverage_curve.csv", index=False)
    reliability.to_csv(output_dir / "ad_reliability_curve.csv", index=False)

    external_summary: dict[str, Any] | None = None
    baseline_external: pd.DataFrame | None = None
    if args.external:
        baseline_external = pd.read_csv(Path(args.external).expanduser())
        baseline_external, _ = select_model(baseline_external, args.model)
        external_diagnosed = add_diagnostics(baseline_external, task, args.tolerance)
        external_diagnosed.to_csv(output_dir / "external_ad_diagnosis.csv", index=False)
        external_summary = {
            "rows": len(external_diagnosed),
            "in_domain_rows": int(external_diagnosed["in_domain"].sum()),
            "success_rate": float(external_diagnosed["engineering_success"].mean()),
            "mean_normalized_error": float(external_diagnosed["normalized_error"].mean()),
        }

    recoverability_summary: dict[str, Any] | None = None
    if args.fine_tuned_external:
        if baseline_external is None or not args.id_col:
            raise ValueError(
                "--fine-tuned-external requires --external and --id-col for paired comparison"
            )
        tuned = pd.read_csv(Path(args.fine_tuned_external).expanduser())
        tuned, _ = select_model(tuned, args.model)
        paired = recoverability(
            baseline_external, tuned, args.id_col, task, args.tolerance
        )
        paired.to_csv(output_dir / "fine_tuning_recoverability.csv", index=False)
        recoverability_summary = {
            "paired_rows": len(paired),
            "mean_coverage_gain": float(paired["coverage_gain"].mean()),
            "mean_error_reduction": float(paired["error_reduction"].mean()),
            "regime_counts": paired["recoverability_regime"].value_counts().to_dict(),
        }

    summary = {
        "input": str(input_path.resolve()),
        "model": selected_model,
        "task": task,
        "rows": len(diagnosed),
        "regression_tolerance": args.tolerance,
        "success_probability_target": args.success_probability,
        "normalized_ad_reliability_boundary": boundary,
        "oof_success_rate": float(diagnosed["engineering_success"].mean()),
        "oof_in_domain_rate": float(diagnosed["in_domain"].mean()),
        "external": external_summary,
        "fine_tuning_recoverability": recoverability_summary,
        "warning": (
            "The calibrated boundary is conditional on the current data, folds, engineering "
            "tolerance, and model. Recalibrate after changing the material system or protocol."
        ),
    }
    (output_dir / "ad_reliability_summary.json").write_text(
        json.dumps(json_safe(summary), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Artifacts written to {output_dir}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise

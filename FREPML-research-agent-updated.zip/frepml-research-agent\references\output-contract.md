# Output Contract

Every completed workflow should make the following artifacts easy to locate and audit.

## Required

- `data_audit.json` and `data_audit.md`: row/column counts, target quality, duplicates, missingness, group structure, SMILES validity, and leakage warnings.
- A feature table plus its manifest: input fingerprint, representation parameters, software versions, feature names, invalid-row policy, and generated dimensions.
- `model_comparison.csv`: pooled out-of-fold metrics and fold dispersion for every attempted model.
- `oof_predictions.csv`: row identity, fold, observed target, model prediction, and probability when applicable.
- `benchmark_manifest.json`: split type, group column, folds, seed, features, feature-selection mode, audited outcome exclusions, package versions, failures, selected metric, and selected model.
- `best_pipeline.joblib` or the equivalent graph checkpoint: final full-development-data refit, labeled as such.
- A concise research report describing data, method, validation, results, limitations, applicability domain, and next experiment.

## Required when the corresponding module is selected

- Process compression: `process_feature_manifest.json` with stage-column mapping, units, missing-stage policy, formulas, and generated columns.
- Representation ablation: `representation_comparison.csv`, `representation_oof_predictions.csv`, `representation_selected_summary.csv`, and `representation_comparison_manifest.json`; also write `paired_representation_differences.csv` when a baseline is defined.
- External prediction: an external prediction CSV plus its `.manifest.json`, including measured-label availability, external metrics, AD distance, threshold, and in-domain flag when available.
- Reliability-calibrated AD: `ad_oof_diagnostics.csv`, `risk_coverage_curve.csv`, `ad_reliability_curve.csv`, and `ad_reliability_summary.json`.
- Sparse-label adaptation: `fine_tuning_recoverability.csv` with paired coverage gain, error reduction, and diagnostic regime.
- GNN studies: record `fusion_mode` so graph-only and graph–tabular results cannot be conflated.

## Claim rules

- Call cross-validation results `out-of-fold`, not external validation.
- Call the final saved model a `full-data refit`; do not present its fit score as performance evidence.
- State when folds are random rather than group-, scaffold-, source-, or time-aware.
- State how many rows and independent groups produced each metric.
- State failed or unavailable representations, including alvaDesc licensing or GNN dependency failures.
- Label out-of-domain predictions and avoid confident recommendations outside the measured chemical/material space.
- Say one representation outperformed another only when both used the same eligible samples and folds.
- State whether the learner was fixed across representations or independently selected for each representation.
- Report unique formulations separately from task-level label counts.
- Call post-external-label results adaptation or fine-tuning, not untouched external validation.

## Reproducibility

Preserve the executed command, input path and file hash, target, excluded columns, feature order, split assignments, seed, dependency versions, and warnings. Prefer JSON/CSV artifacts over results that exist only in terminal output.

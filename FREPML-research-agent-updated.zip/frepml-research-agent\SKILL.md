---
name: frepml-research-agent
description: Build, audit, compare, and report reproducible machine-learning workflows for tabular, materials, formulation, process, and molecular datasets. Use when Codex needs to inspect CSV/XLSX data, prevent leakage, choose RDKit fingerprints/descriptors or licensed alvaDesc, encode multi-component roles, derive curing/process features, compare explicit descriptor–process representations with graph or fusion models, run optional TabICL/TabPFN baselines, validate with grouped/scaffold-aware splits, calibrate applicability-domain reliability, analyze untouched external data or sparse-label adaptation, and package OOF evidence plus final models.
---

# FREPML Research Agent

Turn a user dataset and scientific question into an auditable ML workflow. Prefer pooled out-of-fold evidence over a visually impressive split. Treat representation, process encoding, model family, validation, applicability, and external adaptation as explicit user-selectable experimental choices.

## Start Here

1. Identify the dataset, target, task, row identity, molecular-role columns, formulation/process columns, grouping variables, and intended prediction use.
2. Read [validation-protocol.md](references/validation-protocol.md) before designing a split or interpreting metrics.
3. Read [molecular-representations.md](references/molecular-representations.md) when molecular structures are present.
4. Read [descriptor-process-workflow.md](references/descriptor-process-workflow.md) when the user wants process features, representation ablations, graph/fusion comparisons, tabular foundation models, SHAP interpretation, external validation, or reliability-calibrated AD.
5. Run `scripts/audit_dataset.py` before modeling. Inspect both JSON and Markdown outputs.
6. Generate only the representations and process modules the user selected.
7. Run tabular and optional graph benchmarks on the same eligible rows and folds.
8. Check every artifact against [output-contract.md](references/output-contract.md) before making conclusions.

For sparse multi-property tables, audit and model one target at a time. Use `--include-cols` and `--include-prefixes` as a feature allow-list, or explicitly exclude every other outcome, post-test measurement, and adaptation-only field. Never let another property label enter the predictors merely because it is numeric.

Do not silently guess a target, ID, grouping variable, engineering tolerance, or external-label role when several choices are plausible. If the data resolves the ambiguity, proceed and record the choice; otherwise ask one concise question.

## Method-Choice Contract

Give the user control over the research design. Present relevant options, recommend a proportionate starting set, and record which modules were selected, declined, or unavailable.

Offer choices across:

- representation: formulation, explicit descriptors, fingerprints, process features, graph-only, or graph–tabular fusion;
- model family: linear/kernel, bagging, boosting, MLP, optional TabICL/TabPFN, or optional GNN;
- validation: grouped, scaffold, source, family, time, or random only when defensible;
- interpretation: none, correlation, grouped importance, SHAP, interactions, local failures, or stability audits;
- reliability: geometric AD only, risk–coverage, tolerance-calibrated success probability, external prediction, or sparse-label recoverability.

Do not run every expensive method by default. Use a lightweight baseline unless the user requests a broader comparison or the scientific claim requires it. Do not present a paper-inspired option as mandatory or universally superior.

## Representation Decision

Choose one or more representations and compare them under identical folds:

- Start with `rdkit-descriptors` when interpretability, low sample size, or physicochemical signal matters. Use `rdkit-descriptors-3d` for conformer-dependent families or `rdkit-descriptors-all` for both.
- Start with `morgan-bit` for a strong structural baseline. Add `morgan-count` when motif multiplicity matters.
- Add `rdkit-fingerprint`, `maccs`, `atom-pair`, `topological-torsion`, `pattern`, or `layered` when they match the hypothesis.
- Use `avalon` only when the installed RDKit build exposes it.
- Use `alvadesc` only with a working installation and license. Discover or ask for the executable path. Never imply that alvaDesc is free or bundled.
- Use `gnn` as a separately validated comparison when topology is central or data support it. Retain descriptor/fingerprint tabular controls on small data.
- Use paper-inspired M0–M4 descriptor–process ablations only when they answer a representation question; see the dedicated reference.

If alvaDesc is requested but unavailable, preserve the requested settings in the manifest, report the dependency or license issue, and offer RDKit descriptors plus Morgan as separately labeled fallbacks. Do not fabricate alvaDesc columns.

For multiple components, pass every SMILES role separately, prefix features by role, and retain formulation ratios and process variables. Never concatenate independent components into a chemically false molecule.

## Core Commands

Audit a dataset:

```powershell
python scripts/audit_dataset.py --input data.xlsx --target LOI --smiles-cols EP_SMILES FR_SMILES --group-col paper_id --output-dir outputs/audit
```

Compute molecular features:

```powershell
python scripts/compute_molecular_features.py --input data.xlsx --output outputs/morgan.csv --smiles-cols EP_SMILES FR_SMILES --representation morgan-bit --radius 2 --n-bits 2048
python scripts/compute_molecular_features.py --input data.xlsx --output outputs/rdkit.csv --smiles-cols EP_SMILES FR_SMILES --representation rdkit-descriptors
python scripts/compute_molecular_features.py --input data.xlsx --output outputs/alvadesc.csv --smiles-cols EP_SMILES FR_SMILES --representation alvadesc --alvadesc-exe "C:\Program Files\Alvascience\alvaDesc\alvaDescCLI.exe" --alvadesc-block ALL
```

Derive optional multi-stage process summaries:

```powershell
python scripts/derive_process_features.py --input data.xlsx --output outputs/with_process.csv --temperature-cols cure_T1 cure_T2 cure_T3 --time-cols cure_h1 cure_h2 cure_h3 --missing-policy strict
```

Run a selected tabular panel and save fold-specific AD distances:

```powershell
python scripts/run_tabular_benchmark.py --input outputs/with_process.csv --target LOI --task regression --group-col paper_id --exclude-cols sample_id Tg tensile_strength UL94 --include-prefixes formulation_ descriptor_ process_ --models ridge extra_trees tabicl --primary-metric mae --ad-mode knn-distance --output-dir outputs/benchmark --folds 5
```

Restrict a representation by exact columns and prefixes:

```powershell
python scripts/run_tabular_benchmark.py --input outputs/features.csv --target LOI --group-col paper_id --models extra_trees --include-cols EP_loading FR_loading EEW process_T_max process_t_total process_Q_thermal --include-prefixes EP_ FR_ CURING_ --ad-mode knn-distance --output-dir outputs/M2
```

Compare separately run representations after verifying fold identity:

```powershell
python scripts/compare_representation_runs.py --runs M0=outputs/M0 M1=outputs/M1 M2=outputs/M2 M3=outputs/M3 M4=outputs/M4 --baseline M0 --output-dir outputs/representation_study
```

Run pure graph and graph–tabular fusion as separate choices:

```powershell
python scripts/run_gnn_baseline.py --input data.xlsx --target LOI --task regression --smiles-cols EP_SMILES FR_SMILES CURING_SMILES --fusion-mode graph-only --group-col paper_id --architecture gin --output-dir outputs/gnn_graph_only
python scripts/run_gnn_baseline.py --input data.xlsx --target LOI --task regression --smiles-cols EP_SMILES FR_SMILES CURING_SMILES --fusion-mode concat --numeric-cols FR_loading process_T_max process_t_total process_Q_thermal --group-col paper_id --architecture gin --output-dir outputs/gnn_fusion
```

Predict an untouched external table and analyze task-specific reliability:

```powershell
python scripts/predict_external.py --pipeline outputs/benchmark/best_pipeline.joblib --input external.xlsx --output outputs/external_predictions.csv --id-col sample_id --observed-col LOI
python scripts/analyze_ad_reliability.py --input outputs/benchmark/oof_predictions.csv --model extra_trees --task regression --tolerance 2.0 --external outputs/external_predictions.csv --id-col sample_id --output-dir outputs/ad_reliability
```

Use `--help` for the full option set. Install optional dependencies only with the user's permission. Treat TabICL/TabPFN package defaults as version-dependent; record package/checkpoint details and verify model-weight terms for the intended use.

## Validation Rules

- Split by the unit that could leak: paper, formulation family, polymer system, molecule, scaffold, batch, patient, site, or time.
- Put imputation, scaling, filtering, supervised feature selection, tuning, calibration, and threshold selection inside training folds.
- Report pooled OOF predictions and fold dispersion. Never select the best fold as the headline result.
- Deduplicate before splitting and keep alternate measurements of the same system together.
- Keep a final external set untouched until model and representation choices are frozen.
- Assess similarity or distance to training data and label out-of-domain predictions.
- Compare representations on identical rows, folds, target handling, learner, and metrics when making a representation claim.
- In a sparse multi-target table, use an explicit feature allow-list and verify that no other outcome or post-test column is a predictor.
- Treat randomized SMILES as alternate encodings, not independent molecules.
- Separate model-selection evidence from the full-data refit artifact.
- Keep unique-system counts separate from task-level label counts.
- Call post-label external work adaptation or fine-tuning, not untouched external validation.

## Completion Criteria

Deliver the artifacts defined in [output-contract.md](references/output-contract.md). State what was selected, run, declined, or unavailable; which split protected against leakage; what pooled OOF evidence shows; whether the learner was fixed across representations; how process history was encoded; what external labels were untouched or reused; and where the model should not be trusted. Do not claim a method is superior unless paired comparisons under identical eligible rows and folds support it.

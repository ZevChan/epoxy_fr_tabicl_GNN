# Selectable Descriptor–Process Study

## Contents

1. Method-choice gate
2. Process representation
3. Representation ablations
4. Model families
5. Graph and fusion choices
6. Interpretation choices
7. Applicability and external validation
8. Reporting rules

This module generalizes a paper workflow for flame-retardant epoxy systems. Its original task pattern included LOI, glass-transition temperature, and tensile-strength regression plus UL-94 classification; formulation, molecular, and staged-curing information; internal grouped OOF comparison; and an external batch with task-sparse labels. Treat those targets and material roles as examples, not required schema.

## 1. Method-choice gate

Treat every module below as optional. Ask the user to choose the scientific scope, compute budget, and dependencies before running expensive methods. Record selected, declined, and unavailable modules in the benchmark manifest or report.

Offer these starting scopes without forcing them:

| Scope | Representations | Models | Reliability work |
|---|---|---|---|
| Minimal | formulation, RDKit descriptors, Morgan | ridge/logistic, ExtraTrees, histogram gradient boosting | grouped OOF plus geometric AD |
| Standard | paired M0–M4 ablation | one fixed learner for representation effects, then a selected model panel; optional TabICL/TabPFN | OOF risk–coverage, external prediction if available |
| Extended | M0–M4, multiple fingerprints, optional alvaDesc | classical panel, tabular foundation models, graph-only and graph–tabular fusion | paired learning curves, SHAP stability, calibrated AD, sparse-label recoverability |

Do not equate “extended” with “better.” Choose the smallest design that can answer the stated scientific question.

## 2. Process representation

For a multi-stage temperature program, optionally derive:

- `T_max = max(T_i)`;
- `t_total = sum(t_i)`;
- `Q_thermal = sum(T_i * t_i)`.

Generate them with `scripts/derive_process_features.py`. Keep the original stage columns and units. Treat `Q_thermal` as a compact thermal-history summary, not a cure-kinetics model. High-temperature/short-time and low-temperature/long-time paths can have similar integrals but different chemistry.

Retain direct variables when available: stoichiometric ratios, epoxy equivalent weight, active-hydrogen equivalent weight, catalyst, pressure, atmosphere, ramp rate, conversion, and post-cure conditions.

## 3. Representation ablations

Use the following paper-inspired variants only as a naming template. Adapt column groups to the actual material system.

| Variant | Included information | Scientific question |
|---|---|---|
| M0 | formulation variables | How much signal exists without molecular or process descriptors? |
| M1 | M0 + explicit molecular descriptors | Do domain-readable molecular variables add label-efficient information? |
| M2 | M1 + process variables | Does process history add information after formulation and molecules? |
| M3 | formulation + process + topology proxy such as Morgan | Can a topology proxy replace explicit descriptors? |
| M4 | M2 + topology proxy | Does topology add net information after the full explicit representation? |

Use `run_tabular_benchmark.py --include-cols ... --include-prefixes ...` to select each feature block without rewriting the table. Run every variant on the same source rows, target handling, group definition, folds, seed, learner, and metric. Use `compare_representation_runs.py` to verify fold identity before comparing results.

When several sparse property labels share one table, run each target on its own eligible cohort. Use an explicit feature allow-list and exclude all other outcomes, post-test measurements, and adaptation-only fields. The benchmark runner warns when it falls back to every eligible numeric column because that convenience mode can leak another property label.

For a clean representation claim, run one fixed learner across all variants. If each representation selects its own best model, label the result a joint representation-plus-model comparison.

When studying sample efficiency, use paired nested training subsets inside each outer training fold. Reuse the same subset indices for every representation and report the performance floor as well as the mean or median. Do not create a learning curve by independently resampling each representation.

Interpret `M2 - M3` as a conditional representation difference under the chosen learner and sample size. Interpret `M4 - M2 < 0` as possible redundancy, noise, or finite-sample dimensional burden—not evidence that topology is physically irrelevant.

## 4. Model families

Let the user choose any subset of:

- linear and regularized: ridge, elastic net, Bayesian ridge, logistic regression;
- kernel: SVR or SVC;
- bagging and trees: random forest, ExtraTrees;
- boosting: gradient boosting, histogram gradient boosting, XGBoost, LightGBM, CatBoost;
- neural tabular: MLP;
- tabular foundation: TabICL or TabPFN;
- molecular graph: GCN, GraphSAGE, GAT, or GIN baseline.

Keep the `auto` tabular panel lightweight. Run optional packages only when installed and explicitly selected. TabICL and TabPFN may download checkpoints on first use and can be compute-intensive. Record package version, checkpoint/model version when exposed, hardware, and license constraints. Do not call the current package default an exact reproduction of a paper unless the checkpoint is pinned.

Select models with pooled OOF evidence. Never headline the best fold. Use nested validation when tuning or supervised feature selection is central to the claim.

Choose the saved refit's selection metric explicitly when engineering priorities differ from the default: for example `--primary-metric mae` for error magnitude, or `--primary-metric balanced_accuracy` for imbalanced classification. Record that choice before inspecting the external batch.

## 5. Graph and fusion choices

Choose explicitly between:

- `graph-only`: encode each molecular role in the graph and omit numeric formulation/process/descriptor inputs;
- `concat`: concatenate the graph embedding with selected numeric formulation, process, or descriptor features.

Use `run_gnn_baseline.py --fusion-mode graph-only` or `--fusion-mode concat`. Compare both modes on identical eligible rows and folds. The bundled GNN is a transparent baseline, not a reproduction of every chemical-aware or gated fusion architecture.

For a more advanced study, optionally compare separate role encoders, weighted/gated/attention/FiLM fusion, chemically enriched atom/bond features, and equal-width graph/tabular branches. Treat each addition as a new architecture requiring its own validation; do not assume complexity is beneficial on small data.

## 6. Interpretation choices

Choose one or more interpretation levels:

1. correlation and distribution diagnosis;
2. grouped permutation or SHAP importance;
3. global dependence and interaction surfaces;
4. local explanations for representative, high-performing, and failure cases;
5. cross-fold and cross-model stability of response transitions.

Fit supervised selectors and explainers inside training folds when their output supports a performance claim. A full-data refit can be explained for deployment understanding, but its explanation is not OOF evidence.

Treat SHAP values as learned associations. Do not infer reaction pathways, causal mechanisms, gas/condensed-phase roles, or deterministic formulation thresholds without independent evidence. Call apparent change points “response transition regions.” Report their variation across folds and model families.

Audit blind spots that static inputs commonly miss: reaction participation, covalent network formation, actual degree of cure, phase morphology, interfacial state, defects, fracture behavior, and dynamic combustion chemistry.

## 7. Applicability and external validation

Generate fold-specific distances with `run_tabular_benchmark.py --ad-mode knn-distance`. Fit distance transforms and thresholds on training rows only.

Use `scripts/analyze_ad_reliability.py` to convert OOF distance into:

- risk–coverage behavior after rejecting distant samples;
- a task-specific probability of engineering success;
- a reliability boundary based on a user-defined regression tolerance or correct classification;
- external geometric-domain exposure;
- coverage gain versus error reduction after sparse-label fine-tuning.

Do not treat the geometric `d95` threshold as a universal success boundary. Calibrate reliability separately for each task and engineering tolerance. Recalibrate after changing the material family, test method, or model.

Apply a saved full-data refit to an untouched external table with `scripts/predict_external.py`. Preserve baseline external predictions before using any external labels. Report each property on the subset that actually has a measured label; do not sum label counts and call them unique formulations when tasks overlap.

For sparse-label adaptation:

1. save zero-shot external predictions and AD distances;
2. define which external labels may be used for adaptation;
3. keep a separate external subset or use an external-only validation fold;
4. rerun the selected pipeline without changing the original headline OOF result;
5. compare paired changes in normalized AD distance and normalized error.

Interpret a distance decrease without error reduction as a possible representation-limited failure. Interpret rapid error reduction with little distance change as a possible calibration shift. These labels are diagnostic categories, not mechanistic proof.

## 8. Reporting rules

- Separate interpolation performance, geometric coverage, calibrated reliability, and external performance.
- Report unique systems and task-level label counts separately.
- Preserve all failed optional models and missing dependencies in the manifest.
- State whether representation comparisons fixed the learner or allowed model selection.
- State whether process summaries or raw stage variables were used.
- Report external fine-tuning as adaptation, not untouched external validation.
- Deploy out-of-domain predictions as low-confidence, rejected, or review-required outputs according to the user’s risk tolerance.

The workflow is inspired by the descriptor–process, representation-ablation, external-validation, and reliability analyses in *Explicit Descriptor–Process Learning for Flame Retardancy Epoxy Resin Prediction under Data-Limited Conditions*. Do not transfer its numerical transition regions or performance values to another dataset as defaults.

For current third-party interfaces and model terms, verify the official projects before running: https://github.com/soda-inria/tabicl and https://github.com/PriorLabs/TabPFN.

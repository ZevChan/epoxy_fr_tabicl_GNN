# Validation Protocol

## 1. Define the prediction unit

Write down one row's scientific meaning before modeling. Decide whether repeated rows share a molecule, formulation, polymer family, paper, batch, patient, site, or time period. That shared unit usually becomes the group column.

Deduplicate exact rows and inspect conflicting targets for identical systems. Keep replicates or alternate measurements together in the same fold. Never let the same chemical system appear in both train and validation under different names or randomized SMILES.

## 2. Choose the split

Use the strongest defensible split:

1. Independent prospective or later-time external data.
2. Held-out source, site, paper, batch, polymer family, formulation family, molecule, or scaffold.
3. Grouped cross-validation by the best available leakage unit.
4. Stratified random cross-validation only when rows are genuinely independent.

For a molecular discovery claim, prefer scaffold or molecule-family splits over random row splits. For formulation/process optimization, group all versions of a base material system.

Use at least two folds and no more folds than groups or minority-class examples allow. Record the exact folds and random seed so every representation uses the same partitions.

## 3. Keep learning inside the fold

Fit all learned transformations on training rows only:

- missing-value imputation;
- scaling and normalization;
- variance or correlation filtering;
- supervised feature selection;
- dimensionality reduction;
- resampling or class balancing;
- hyperparameter selection;
- probability calibration and threshold selection.

Use nested cross-validation when extensive hyperparameter search or supervised feature selection is part of the scientific claim. A light fixed-model benchmark can use one grouped cross-validation layer, but its model choice remains exploratory.

## 4. Report pooled out-of-fold evidence

For sparse multi-target tables, model one target at a time and prevent every other outcome, post-test measurement, or adaptation-only field from entering the feature matrix.

For regression, report at least R², RMSE, and MAE on pooled out-of-fold predictions. Add fold mean and standard deviation as stability evidence. Include target range and sample count so error magnitude is interpretable.

For classification, report balanced accuracy and macro F1. Add ROC AUC for binary tasks only when both classes exist in every relevant validation fold and probabilities are available. For strong imbalance, include PR AUC, per-class recall, and a confusion matrix.

Do not average fold R² as the only headline score; pooled predictions are easier to audit. Do not report the best fold as expected performance.

## 5. External validation and applicability

An external set must not influence feature choice, hyperparameters, stopping, or model selection. Report its metrics separately from cross-validation.

Define an applicability-domain method before interpreting extrapolations. Useful options include:

- maximum Tanimoto similarity to training fingerprints;
- leverage or robust distance for descriptor space;
- nearest-neighbor distance after training-fold scaling;
- ensemble disagreement or calibrated predictive intervals;
- explicit material-family or scaffold membership.

Fit the domain threshold on training data only. Label predictions outside it. A numerical prediction outside the domain is not automatically evidence of reliable extrapolation.

When engineering tolerances are available, calibrate distance against out-of-fold success rather than treating a geometric threshold as a universal reliability boundary. For regression, define success as absolute error within a recorded tolerance. For classification, define success as a correct decision at the recorded threshold. Report risk–coverage behavior after progressively rejecting distant samples.

Treat applicability as task-specific. The same formulation can be geometrically close yet reliable for one target and unreliable for another because the input representation may omit target-relevant information.

### Sparse-label adaptation

Preserve zero-shot external predictions before using any external labels. If labels are later used for fine-tuning or recalibration, call the result adaptation rather than untouched external validation. Compare paired changes in normalized AD distance and error. A smaller distance without error reduction suggests that coverage improved while the representation remained inadequate; rapid error reduction with little distance change suggests a calibration shift.

Keep unique formulations distinct from task-level label records. If one formulation provides both LOI and UL-94 labels, count it once as a system and once in each relevant task cohort.

## 6. Compare methods fairly

Use identical eligible rows, folds, targets, and metrics for every representation and algorithm. If a representation fails on invalid molecules, either repair the structures before the experiment or use the same retained-row set across all methods. Report paired fold or row-level differences when saying one method is better.

For small molecular datasets, compare GNNs with at least one descriptor model and one fingerprint model. A more complex neural architecture is not presumed superior.

## 7. Final refit

After model and representation selection, refit the selected pipeline on all development data for deployment. Label this artifact `full-data refit`; its training score is not a validation metric. Preserve feature order, software versions, preprocessing, target transform, random seed, and domain rule alongside the model.

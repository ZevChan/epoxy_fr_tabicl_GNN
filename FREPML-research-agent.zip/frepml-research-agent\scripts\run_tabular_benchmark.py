#!/usr/bin/env python3
"""Run leakage-aware classical ML baselines with pooled out-of-fold predictions."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
import warnings
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.base import clone
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.ensemble import (
    ExtraTreesClassifier,
    ExtraTreesRegressor,
    HistGradientBoostingClassifier,
    HistGradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.feature_selection import VarianceThreshold
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    roc_auc_score,
)
from sklearn.model_selection import GroupKFold, KFold, StratifiedKFold
from sklearn.neighbors import NearestNeighbors
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, StandardScaler


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Benchmark fixed classical models with grouped or stratified cross-validation."
    )
    parser.add_argument("--input", required=True, help="Numeric feature table in CSV/TSV/XLSX")
    parser.add_argument("--target", required=True)
    parser.add_argument(
        "--task", choices=["auto", "regression", "classification"], default="auto"
    )
    parser.add_argument("--id-col", help="Optional row identifier copied to OOF output")
    parser.add_argument("--group-col", help="Group column for leakage-safe cross-validation")
    parser.add_argument(
        "--scaffold-smiles-col",
        help="Build Bemis-Murcko scaffold groups from this SMILES column",
    )
    parser.add_argument(
        "--exclude-cols",
        nargs="*",
        default=[],
        help="Columns to exclude; comma-separated input is also accepted",
    )
    parser.add_argument(
        "--models",
        nargs="*",
        default=["auto"],
        help="auto or names: dummy ridge logistic random_forest extra_trees hist_gradient xgboost lightgbm catboost",
    )
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--n-jobs", type=int, default=-1)
    parser.add_argument("--quick", action="store_true", help="Use smaller tree ensembles")
    parser.add_argument(
        "--ad-mode",
        choices=["none", "knn-distance"],
        default="none",
        help="Optional fold-specific nearest-neighbor applicability distance",
    )
    parser.add_argument("--sheet", default=0)
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args()


def normalize_list(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        result.extend(part.strip() for part in value.split(",") if part.strip())
    return list(dict.fromkeys(result))


def read_table(path: Path, sheet: str | int = 0) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    if suffix in {".xls", ".xlsx", ".xlsm"}:
        parsed_sheet: str | int = int(sheet) if str(sheet).isdigit() else sheet
        return pd.read_excel(path, sheet_name=parsed_sheet)
    raise ValueError(f"Unsupported input format: {suffix}")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def infer_task(target: pd.Series) -> str:
    clean = target.dropna()
    unique_count = clean.nunique()
    if not pd.api.types.is_numeric_dtype(clean):
        return "classification"
    threshold = max(10, int(math.sqrt(max(len(clean), 1))))
    return "classification" if unique_count <= min(20, threshold) else "regression"


def scaffold_groups(smiles: pd.Series) -> pd.Series:
    try:
        from rdkit import Chem
        from rdkit.Chem.Scaffolds import MurckoScaffold
    except ImportError as exc:
        raise RuntimeError("RDKit is required for --scaffold-smiles-col") from exc

    groups: list[str] = []
    for position, value in enumerate(smiles):
        molecule = None if pd.isna(value) else Chem.MolFromSmiles(str(value))
        if molecule is None:
            groups.append(f"__invalid_{position}")
            continue
        scaffold = MurckoScaffold.MurckoScaffoldSmiles(mol=molecule)
        if not scaffold:
            scaffold = Chem.MolToSmiles(molecule, canonical=True)
        groups.append(scaffold)
    return pd.Series(groups, index=smiles.index, name="__scaffold_group")


def make_groups(frame: pd.DataFrame, args: argparse.Namespace) -> tuple[pd.Series | None, str | None]:
    if args.group_col and args.scaffold_smiles_col:
        raise ValueError("Use either --group-col or --scaffold-smiles-col, not both")
    if args.scaffold_smiles_col:
        if args.scaffold_smiles_col not in frame:
            raise KeyError(args.scaffold_smiles_col)
        return scaffold_groups(frame[args.scaffold_smiles_col]), f"scaffold:{args.scaffold_smiles_col}"
    if args.group_col:
        if args.group_col not in frame:
            raise KeyError(args.group_col)
        groups = frame[args.group_col].astype(object).copy()
        for position in np.flatnonzero(groups.isna().to_numpy()):
            groups.iloc[position] = f"__missing_group_{position}"
        return groups.astype(str), args.group_col
    return None, None


def make_splits(
    task: str, y: np.ndarray, groups: pd.Series | None, folds: int, seed: int
) -> tuple[list[tuple[np.ndarray, np.ndarray]], str]:
    if folds < 2:
        raise ValueError("--folds must be at least 2")
    if groups is not None:
        unique_groups = groups.nunique()
        if unique_groups < folds:
            raise ValueError(f"Requested {folds} folds but only {unique_groups} groups are available")
        if task == "classification":
            try:
                from sklearn.model_selection import StratifiedGroupKFold

                splitter = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=seed)
                return list(splitter.split(np.zeros(len(y)), y, groups)), "StratifiedGroupKFold"
            except (ImportError, ValueError) as exc:
                warnings.warn(f"StratifiedGroupKFold unavailable ({exc}); using GroupKFold")
        splitter = GroupKFold(n_splits=folds)
        return list(splitter.split(np.zeros(len(y)), y, groups)), "GroupKFold"

    if task == "classification":
        counts = np.bincount(y.astype(int))
        if counts.min() < folds:
            raise ValueError(
                f"Minority class has {counts.min()} rows, fewer than the requested {folds} folds"
            )
        splitter = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
        return list(splitter.split(np.zeros(len(y)), y)), "StratifiedKFold"
    splitter = KFold(n_splits=folds, shuffle=True, random_state=seed)
    return list(splitter.split(np.zeros(len(y)))), "KFold"


def preprocessor() -> Pipeline:
    return Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("variance", VarianceThreshold()),
            ("scaler", StandardScaler()),
        ]
    )


def builtin_models(task: str, seed: int, n_jobs: int, quick: bool) -> dict[str, Any]:
    trees = 100 if quick else 400
    if task == "regression":
        return {
            "dummy": DummyRegressor(strategy="mean"),
            "ridge": Ridge(alpha=1.0),
            "random_forest": RandomForestRegressor(
                n_estimators=trees, min_samples_leaf=2, random_state=seed, n_jobs=n_jobs
            ),
            "extra_trees": ExtraTreesRegressor(
                n_estimators=trees, min_samples_leaf=2, random_state=seed, n_jobs=n_jobs
            ),
            "hist_gradient": HistGradientBoostingRegressor(
                max_iter=100 if quick else 250, l2_regularization=1.0, random_state=seed
            ),
        }
    return {
        "dummy": DummyClassifier(strategy="prior"),
        "logistic": LogisticRegression(
            C=1.0, class_weight="balanced", max_iter=3000, random_state=seed
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=trees,
            min_samples_leaf=2,
            class_weight="balanced_subsample",
            random_state=seed,
            n_jobs=n_jobs,
        ),
        "extra_trees": ExtraTreesClassifier(
            n_estimators=trees,
            min_samples_leaf=2,
            class_weight="balanced",
            random_state=seed,
            n_jobs=n_jobs,
        ),
        "hist_gradient": HistGradientBoostingClassifier(
            max_iter=100 if quick else 250, l2_regularization=1.0, random_state=seed
        ),
    }


def optional_model(name: str, task: str, seed: int, n_jobs: int, quick: bool) -> Any:
    estimators = 100 if quick else 400
    if name == "xgboost":
        try:
            from xgboost import XGBClassifier, XGBRegressor
        except ImportError as exc:
            raise RuntimeError("xgboost is not installed") from exc
        common = dict(n_estimators=estimators, max_depth=6, learning_rate=0.05, random_state=seed, n_jobs=n_jobs)
        return XGBRegressor(**common, objective="reg:squarederror") if task == "regression" else XGBClassifier(**common)
    if name == "lightgbm":
        try:
            from lightgbm import LGBMClassifier, LGBMRegressor
        except ImportError as exc:
            raise RuntimeError("lightgbm is not installed") from exc
        cls = LGBMRegressor if task == "regression" else LGBMClassifier
        return cls(n_estimators=estimators, learning_rate=0.05, random_state=seed, n_jobs=n_jobs, verbosity=-1)
    if name == "catboost":
        try:
            from catboost import CatBoostClassifier, CatBoostRegressor
        except ImportError as exc:
            raise RuntimeError("catboost is not installed") from exc
        cls = CatBoostRegressor if task == "regression" else CatBoostClassifier
        return cls(iterations=estimators, learning_rate=0.05, random_seed=seed, verbose=False, allow_writing_files=False)
    raise KeyError(name)


def select_models(args: argparse.Namespace, task: str) -> tuple[dict[str, Any], dict[str, str]]:
    builtins = builtin_models(task, args.seed, args.n_jobs, args.quick)
    requested = normalize_list(args.models)
    if "auto" in requested:
        requested = list(builtins)
    models: dict[str, Any] = {}
    failures: dict[str, str] = {}
    for name in requested:
        if name in builtins:
            models[name] = builtins[name]
        else:
            try:
                models[name] = optional_model(name, task, args.seed, args.n_jobs, args.quick)
            except Exception as exc:
                failures[name] = str(exc)
    if not models:
        raise RuntimeError(f"No requested model is available: {failures}")
    return models, failures


def regression_metrics(observed: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    return {
        "r2": float(r2_score(observed, predicted)),
        "rmse": float(mean_squared_error(observed, predicted) ** 0.5),
        "mae": float(mean_absolute_error(observed, predicted)),
    }


def classification_metrics(
    observed: np.ndarray, predicted: np.ndarray, probability: np.ndarray | None
) -> dict[str, float]:
    metrics = {
        "accuracy": float(accuracy_score(observed, predicted)),
        "balanced_accuracy": float(balanced_accuracy_score(observed, predicted)),
        "f1_macro": float(f1_score(observed, predicted, average="macro")),
    }
    if probability is not None and len(np.unique(observed)) == 2:
        metrics["roc_auc"] = float(roc_auc_score(observed, probability))
    return metrics


def applicability_distance(
    fitted_pipeline: Pipeline, x_train: pd.DataFrame, x_valid: pd.DataFrame
) -> tuple[np.ndarray, float, np.ndarray]:
    transformed_train = fitted_pipeline[:-1].transform(x_train)
    transformed_valid = fitted_pipeline[:-1].transform(x_valid)
    if len(transformed_train) < 2:
        return np.full(len(x_valid), np.nan), np.nan, np.zeros(len(x_valid), dtype=bool)
    neighbors = NearestNeighbors(n_neighbors=2, metric="euclidean")
    neighbors.fit(transformed_train)
    nearest_train = neighbors.kneighbors(transformed_train, return_distance=True)[0][:, 1]
    threshold = float(np.quantile(nearest_train, 0.95))
    valid_distances = neighbors.kneighbors(
        transformed_valid, n_neighbors=1, return_distance=True
    )[0][:, 0]
    return valid_distances, threshold, valid_distances <= threshold


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    return value


def main() -> int:
    args = parse_args()
    input_path = Path(args.input).expanduser()
    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    if not input_path.is_file():
        raise FileNotFoundError(input_path)
    frame = read_table(input_path, args.sheet)
    if args.target not in frame:
        raise KeyError(args.target)
    referenced_columns = normalize_list(args.exclude_cols) + [
        column
        for column in [args.id_col, args.group_col, args.scaffold_smiles_col]
        if column
    ]
    unknown_columns = [column for column in referenced_columns if column not in frame]
    if unknown_columns:
        raise KeyError(f"Referenced columns not found: {unknown_columns}")

    complete_target = frame[args.target].notna()
    if not complete_target.all():
        print(f"Dropping {(~complete_target).sum()} rows with missing targets")
        frame = frame.loc[complete_target].copy()
    if "__original_index" in frame.columns:
        raise ValueError("Input uses reserved column name __original_index")
    source_index = frame.index.to_numpy(copy=True)
    frame = frame.reset_index(drop=True)
    frame.insert(0, "__original_index", source_index)
    task = infer_task(frame[args.target]) if args.task == "auto" else args.task

    groups, group_label = make_groups(frame, args)
    excluded = set(normalize_list(args.exclude_cols))
    excluded.update(
        column
        for column in [
            args.target,
            args.id_col,
            args.group_col,
            args.scaffold_smiles_col,
            "__original_index",
        ]
        if column
    )
    numeric_columns = [
        str(column)
        for column in frame.select_dtypes(include=np.number).columns
        if column not in excluded
    ]
    if not numeric_columns:
        raise ValueError("No numeric features remain after exclusions")
    x = frame[numeric_columns].replace([np.inf, -np.inf], np.nan)

    label_encoder: LabelEncoder | None = None
    if task == "regression":
        y_series = pd.to_numeric(frame[args.target], errors="coerce")
        if y_series.isna().any():
            raise ValueError("Regression target contains non-numeric values")
        y = y_series.to_numpy(dtype=float)
        class_labels = None
    else:
        label_encoder = LabelEncoder()
        y = label_encoder.fit_transform(frame[args.target].astype(str))
        class_labels = label_encoder.classes_.tolist()
        if len(class_labels) < 2:
            raise ValueError("Classification requires at least two classes")

    splits, split_name = make_splits(task, y, groups, args.folds, args.seed)
    for fold, (train_idx, valid_idx) in enumerate(splits):
        if groups is not None:
            overlap = set(groups.iloc[train_idx]) & set(groups.iloc[valid_idx])
            if overlap:
                raise RuntimeError(f"Group leakage in fold {fold}: {list(overlap)[:5]}")

    models, unavailable_models = select_models(args, task)
    comparison_rows: list[dict[str, Any]] = []
    oof_rows: list[dict[str, Any]] = []
    model_failures: dict[str, str] = dict(unavailable_models)
    fitted_candidates: dict[str, Any] = {}

    for model_name, estimator in models.items():
        print(f"Evaluating {model_name} on {len(splits)} folds")
        oof_prediction = np.full(len(frame), np.nan)
        oof_probability = np.full(len(frame), np.nan)
        fold_number = np.full(len(frame), -1, dtype=int)
        ad_distance = np.full(len(frame), np.nan)
        ad_threshold = np.full(len(frame), np.nan)
        in_domain = np.full(len(frame), False)
        fold_metrics: list[dict[str, float]] = []
        try:
            for fold, (train_idx, valid_idx) in enumerate(splits):
                pipeline = Pipeline([("preprocess", preprocessor()), ("model", clone(estimator))])
                pipeline.fit(x.iloc[train_idx], y[train_idx])
                predicted = pipeline.predict(x.iloc[valid_idx])
                oof_prediction[valid_idx] = predicted
                fold_number[valid_idx] = fold
                probability: np.ndarray | None = None
                if task == "classification" and len(class_labels or []) == 2 and hasattr(pipeline, "predict_proba"):
                    probability = pipeline.predict_proba(x.iloc[valid_idx])[:, 1]
                    oof_probability[valid_idx] = probability
                metrics = (
                    regression_metrics(y[valid_idx], predicted)
                    if task == "regression"
                    else classification_metrics(y[valid_idx], predicted, probability)
                )
                fold_metrics.append(metrics)
                if args.ad_mode == "knn-distance":
                    distances, threshold, domain = applicability_distance(
                        pipeline, x.iloc[train_idx], x.iloc[valid_idx]
                    )
                    ad_distance[valid_idx] = distances
                    ad_threshold[valid_idx] = threshold
                    in_domain[valid_idx] = domain

            pooled = (
                regression_metrics(y, oof_prediction)
                if task == "regression"
                else classification_metrics(
                    y, oof_prediction.astype(int), oof_probability if np.isfinite(oof_probability).all() else None
                )
            )
            row: dict[str, Any] = {"model": model_name, "n_rows": len(frame), **pooled}
            for metric in sorted({key for item in fold_metrics for key in item}):
                values = [item[metric] for item in fold_metrics if metric in item]
                row[f"fold_{metric}_mean"] = float(np.mean(values))
                row[f"fold_{metric}_std"] = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
            comparison_rows.append(row)

            for position in range(len(frame)):
                observed_label: Any = y[position]
                predicted_label: Any = oof_prediction[position]
                if label_encoder is not None:
                    observed_label = label_encoder.inverse_transform([int(y[position])])[0]
                    predicted_label = label_encoder.inverse_transform([int(oof_prediction[position])])[0]
                output_row = {
                    "model": model_name,
                    "row_position": position,
                    "original_index": frame.loc[position, "__original_index"],
                    "fold": int(fold_number[position]),
                    "observed": observed_label,
                    "predicted": predicted_label,
                }
                if args.id_col:
                    output_row[args.id_col] = frame.loc[position, args.id_col]
                if task == "classification" and np.isfinite(oof_probability[position]):
                    output_row[f"probability__{class_labels[1]}"] = oof_probability[position]
                if args.ad_mode != "none":
                    output_row["ad_distance"] = ad_distance[position]
                    output_row["ad_threshold"] = ad_threshold[position]
                    output_row["in_domain"] = bool(in_domain[position])
                oof_rows.append(output_row)
            fitted_candidates[model_name] = estimator
        except Exception as exc:
            model_failures[model_name] = f"{type(exc).__name__}: {exc}"
            print(f"WARNING: {model_name} failed: {exc}", file=sys.stderr)

    if not comparison_rows:
        raise RuntimeError(f"Every model failed: {model_failures}")
    comparison = pd.DataFrame(comparison_rows)
    if task == "regression":
        primary_metric = "r2"
    elif "roc_auc" in comparison.columns and comparison["roc_auc"].notna().any():
        primary_metric = "roc_auc"
    else:
        primary_metric = "balanced_accuracy"
    comparison = comparison.sort_values(primary_metric, ascending=False).reset_index(drop=True)
    best_name = str(comparison.loc[0, "model"])

    final_pipeline = Pipeline(
        [("preprocess", preprocessor()), ("model", clone(fitted_candidates[best_name]))]
    )
    final_pipeline.fit(x, y)
    bundle = {
        "pipeline": final_pipeline,
        "feature_columns": numeric_columns,
        "target": args.target,
        "task": task,
        "class_labels": class_labels,
        "label_encoder": label_encoder,
        "model_name": best_name,
        "applicability_mode": args.ad_mode,
        "note": "Full-development-data refit; validation evidence is in oof_predictions.csv.",
    }
    joblib.dump(bundle, output_dir / "best_pipeline.joblib")
    comparison.to_csv(output_dir / "model_comparison.csv", index=False)
    pd.DataFrame(oof_rows).to_csv(output_dir / "oof_predictions.csv", index=False)

    shared_fold_numbers = np.full(len(frame), -1, dtype=int)
    for fold, (_, valid_idx) in enumerate(splits):
        shared_fold_numbers[valid_idx] = fold
    fold_assignments = pd.DataFrame(
        {
            "row_position": np.arange(len(frame)),
            "original_index": frame["__original_index"],
            "fold": shared_fold_numbers,
        }
    )
    if args.id_col:
        fold_assignments[args.id_col] = frame[args.id_col]
    if groups is not None:
        fold_assignments["validation_group"] = groups
    fold_assignments.to_csv(output_dir / "fold_assignments.csv", index=False)

    manifest = {
        "input": str(input_path.resolve()),
        "input_sha256": sha256_file(input_path),
        "target": args.target,
        "task": task,
        "class_labels": class_labels,
        "rows": len(frame),
        "numeric_feature_count": len(numeric_columns),
        "feature_columns": numeric_columns,
        "excluded_columns": sorted(excluded),
        "splitter": split_name,
        "group_definition": group_label,
        "folds": args.folds,
        "seed": args.seed,
        "applicability_mode": args.ad_mode,
        "models_attempted": list(models),
        "model_failures": model_failures,
        "primary_metric": primary_metric,
        "selected_model": best_name,
        "selected_model_oof_metric": comparison.loc[0, primary_metric],
        "saved_model_status": "full-development-data refit",
        "versions": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scikit_learn": sklearn.__version__,
            "joblib": joblib.__version__,
        },
        "warnings": [
            "This is a fixed-model benchmark, not nested hyperparameter optimization.",
            "The saved pipeline is fitted on all development rows; use OOF metrics for performance claims.",
        ],
    }
    (output_dir / "benchmark_manifest.json").write_text(
        json.dumps(json_safe(manifest), ensure_ascii=False, indent=2), encoding="utf-8"
    )

    best_row = comparison.iloc[0]
    report_lines = [
        "# Benchmark report",
        "",
        f"- Task: {task}",
        f"- Rows: {len(frame)}",
        f"- Numeric features: {len(numeric_columns)}",
        f"- Splitter: {split_name}",
        f"- Group definition: {group_label or 'none (random row-level folds)'}",
        f"- Selected fixed baseline: {best_name}",
        f"- Pooled OOF {primary_metric}: {best_row[primary_metric]:.4f}",
        "",
        "The saved pipeline is a full-data refit. Its training fit is not validation evidence.",
        "",
        "## Model comparison",
        "",
        "```text",
        comparison.to_string(index=False),
        "```",
        "",
    ]
    if model_failures:
        report_lines.extend(["## Unavailable or failed models", ""])
        report_lines.extend(f"- `{name}`: {reason}" for name, reason in model_failures.items())
        report_lines.append("")
    (output_dir / "benchmark_report.md").write_text("\n".join(report_lines), encoding="utf-8")

    print(comparison.to_string(index=False))
    print(f"Selected {best_name} by pooled OOF {primary_metric}")
    print(f"Artifacts written to {output_dir}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise

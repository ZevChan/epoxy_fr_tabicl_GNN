#!/usr/bin/env python3
"""Compute molecular fingerprints, RDKit descriptors, or licensed alvaDesc descriptors."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd


REPRESENTATIONS = [
    "rdkit-descriptors",
    "rdkit-descriptors-3d",
    "rdkit-descriptors-all",
    "morgan-bit",
    "morgan-count",
    "rdkit-fingerprint",
    "maccs",
    "atom-pair",
    "topological-torsion",
    "pattern",
    "layered",
    "avalon",
    "alvadesc",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Append role-prefixed molecular features to a CSV/TSV/XLSX table."
    )
    parser.add_argument("--input", required=True, help="Input CSV, TSV, XLS, or XLSX")
    parser.add_argument("--output", required=True, help="Output CSV, TSV, or XLSX")
    parser.add_argument(
        "--smiles-cols",
        nargs="+",
        required=True,
        help="SMILES columns; comma-separated input is also accepted",
    )
    parser.add_argument("--representation", choices=REPRESENTATIONS, required=True)
    parser.add_argument("--radius", type=int, default=2, help="Morgan radius (default: 2)")
    parser.add_argument("--n-bits", type=int, default=2048, help="Hashed fingerprint size")
    parser.add_argument(
        "--conformer-seed",
        type=int,
        default=42,
        help="Random seed for RDKit 3D conformer generation",
    )
    parser.add_argument(
        "--3d-optimize",
        dest="optimize_3d",
        choices=["mmff", "uff", "none"],
        default="mmff",
        help="Geometry optimization used before 3D descriptors",
    )
    parser.add_argument(
        "--invalid-policy",
        choices=["nan", "zero", "drop"],
        default="nan",
        help="How to handle rows with missing or invalid SMILES",
    )
    parser.add_argument("--sheet", default=0, help="Excel sheet name or zero-based index")
    parser.add_argument("--alvadesc-exe", help="Path to a licensed alvaDesc CLI executable")
    parser.add_argument(
        "--alvadesc-block",
        default="ALL",
        help="ALL, a supported block, or comma-separated descriptor names",
    )
    parser.add_argument("--batch-size", type=int, default=500, help="alvaDesc batch size")
    return parser.parse_args()


def normalize_list(values: list[str]) -> list[str]:
    columns: list[str] = []
    for value in values:
        columns.extend(part.strip() for part in value.split(",") if part.strip())
    return list(dict.fromkeys(columns))


def read_table(path: Path, sheet: str | int = 0) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    if suffix in {".xls", ".xlsx", ".xlsm"}:
        parsed_sheet: str | int = int(sheet) if str(sheet).isdigit() else sheet
        return pd.read_excel(path, sheet_name=parsed_sheet)
    raise ValueError(f"Unsupported input format: {suffix}")


def write_table(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    if suffix == ".csv":
        frame.to_csv(path, index=False)
    elif suffix in {".tsv", ".txt"}:
        frame.to_csv(path, sep="\t", index=False)
    elif suffix in {".xlsx", ".xls"}:
        frame.to_excel(path, index=False)
    else:
        raise ValueError("Output must end in .csv, .tsv, .txt, .xls, or .xlsx")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bit_vector_to_numpy(vector: Any, size: int) -> np.ndarray:
    from rdkit import DataStructs

    values = np.zeros((size,), dtype=np.float32)
    DataStructs.ConvertToNumpyArray(vector, values)
    return values


def prepare_molecules(series: pd.Series) -> tuple[list[Any | None], list[str | None], list[int]]:
    from rdkit import Chem

    molecules: list[Any | None] = []
    canonical: list[str | None] = []
    invalid_rows: list[int] = []
    for position, value in enumerate(series):
        if pd.isna(value) or not str(value).strip():
            molecule = None
        else:
            molecule = Chem.MolFromSmiles(str(value).strip())
        molecules.append(molecule)
        if molecule is None:
            canonical.append(None)
            invalid_rows.append(position)
        else:
            canonical.append(Chem.MolToSmiles(molecule, canonical=True))
    return molecules, canonical, invalid_rows


def matrix_from_molecules(
    molecules: list[Any | None],
    feature_names: list[str],
    calculator: Callable[[Any], np.ndarray],
) -> np.ndarray:
    matrix = np.full((len(molecules), len(feature_names)), np.nan, dtype=np.float64)
    for row, molecule in enumerate(molecules):
        if molecule is None:
            continue
        try:
            values = np.asarray(calculator(molecule), dtype=np.float64)
            if values.shape != (len(feature_names),):
                raise ValueError(f"Expected {len(feature_names)} values, got {values.shape}")
            values[~np.isfinite(values)] = np.nan
            matrix[row] = values
        except Exception as exc:
            print(f"WARNING: feature calculation failed on row {row}: {exc}", file=sys.stderr)
    return matrix


def rdkit_descriptor_features(molecules: list[Any | None]) -> tuple[list[str], np.ndarray]:
    from rdkit.Chem import Descriptors

    registry = getattr(Descriptors, "descList", None) or getattr(Descriptors, "_descList")
    names = [str(name) for name, _ in registry]

    def calculate(molecule: Any) -> np.ndarray:
        result = []
        for _, function in registry:
            try:
                value = float(function(molecule))
            except Exception:
                value = np.nan
            result.append(value)
        return np.asarray(result, dtype=np.float64)

    return names, matrix_from_molecules(molecules, names, calculate)


def rdkit_3d_descriptor_features(
    molecules: list[Any | None], conformer_seed: int, optimize_3d: str
) -> tuple[list[str], np.ndarray]:
    from rdkit import Chem
    from rdkit.Chem import AllChem, rdMolDescriptors

    vector_families = [
        ("AUTOCORR3D", rdMolDescriptors.CalcAUTOCORR3D, 80),
        ("MORSE", rdMolDescriptors.CalcMORSE, 224),
        ("RDF", rdMolDescriptors.CalcRDF, 210),
        ("WHIM", rdMolDescriptors.CalcWHIM, 114),
        ("GETAWAY", rdMolDescriptors.CalcGETAWAY, 273),
    ]
    scalar_families = [
        ("PMI1", rdMolDescriptors.CalcPMI1),
        ("PMI2", rdMolDescriptors.CalcPMI2),
        ("PMI3", rdMolDescriptors.CalcPMI3),
        ("NPR1", rdMolDescriptors.CalcNPR1),
        ("NPR2", rdMolDescriptors.CalcNPR2),
        ("Asphericity", rdMolDescriptors.CalcAsphericity),
        ("Eccentricity", rdMolDescriptors.CalcEccentricity),
        ("InertialShapeFactor", rdMolDescriptors.CalcInertialShapeFactor),
        ("RadiusOfGyration", rdMolDescriptors.CalcRadiusOfGyration),
        ("SpherocityIndex", rdMolDescriptors.CalcSpherocityIndex),
    ]
    names: list[str] = []
    for family, _, length in vector_families:
        names.extend(f"{family}_{index:03d}" for index in range(length))
    names.extend(name for name, _ in scalar_families)

    def calculate(molecule: Any) -> np.ndarray:
        molecule_3d = Chem.AddHs(Chem.Mol(molecule))
        params = AllChem.ETKDGv3() if hasattr(AllChem, "ETKDGv3") else AllChem.ETKDG()
        params.randomSeed = int(conformer_seed)
        status = AllChem.EmbedMolecule(molecule_3d, params)
        if status != 0:
            retry = AllChem.ETKDG()
            retry.randomSeed = int(conformer_seed)
            retry.useRandomCoords = True
            status = AllChem.EmbedMolecule(molecule_3d, retry)
        if status != 0:
            raise RuntimeError("RDKit could not generate a 3D conformer")
        if optimize_3d == "mmff":
            if AllChem.MMFFHasAllMoleculeParams(molecule_3d):
                AllChem.MMFFOptimizeMolecule(molecule_3d, maxIters=500)
            elif AllChem.UFFHasAllMoleculeParams(molecule_3d):
                AllChem.UFFOptimizeMolecule(molecule_3d, maxIters=500)
        elif optimize_3d == "uff" and AllChem.UFFHasAllMoleculeParams(molecule_3d):
            AllChem.UFFOptimizeMolecule(molecule_3d, maxIters=500)

        values: list[float] = []
        for _, function, length in vector_families:
            try:
                family_values = list(function(molecule_3d))
                if len(family_values) != length:
                    raise ValueError(f"expected {length}, got {len(family_values)}")
                values.extend(float(value) for value in family_values)
            except Exception:
                values.extend([np.nan] * length)
        for _, function in scalar_families:
            try:
                values.append(float(function(molecule_3d)))
            except Exception:
                values.append(np.nan)
        return np.asarray(values, dtype=np.float64)

    return names, matrix_from_molecules(molecules, names, calculate)


def fingerprint_features(
    molecules: list[Any | None], representation: str, radius: int, n_bits: int
) -> tuple[list[str], np.ndarray]:
    from rdkit import Chem
    from rdkit.Chem import MACCSkeys, rdFingerprintGenerator

    if representation == "maccs":
        size = 167
        calculator = lambda molecule: bit_vector_to_numpy(MACCSkeys.GenMACCSKeys(molecule), size)
    elif representation == "morgan-bit":
        generator = rdFingerprintGenerator.GetMorganGenerator(radius=radius, fpSize=n_bits)
        size = n_bits
        calculator = lambda molecule: bit_vector_to_numpy(generator.GetFingerprint(molecule), size)
    elif representation == "morgan-count":
        generator = rdFingerprintGenerator.GetMorganGenerator(radius=radius, fpSize=n_bits)
        size = n_bits

        def calculator(molecule: Any) -> np.ndarray:
            if hasattr(generator, "GetCountFingerprintAsNumPy"):
                return np.asarray(generator.GetCountFingerprintAsNumPy(molecule), dtype=np.float64)
            return bit_vector_to_numpy(generator.GetCountFingerprint(molecule), size)

    elif representation == "atom-pair":
        generator = rdFingerprintGenerator.GetAtomPairGenerator(fpSize=n_bits)
        size = n_bits
        calculator = lambda molecule: bit_vector_to_numpy(generator.GetFingerprint(molecule), size)
    elif representation == "topological-torsion":
        generator = rdFingerprintGenerator.GetTopologicalTorsionGenerator(fpSize=n_bits)
        size = n_bits
        calculator = lambda molecule: bit_vector_to_numpy(generator.GetFingerprint(molecule), size)
    elif representation == "rdkit-fingerprint":
        size = n_bits
        calculator = lambda molecule: bit_vector_to_numpy(
            Chem.RDKFingerprint(molecule, fpSize=size), size
        )
    elif representation == "pattern":
        size = n_bits
        calculator = lambda molecule: bit_vector_to_numpy(
            Chem.PatternFingerprint(molecule, fpSize=size), size
        )
    elif representation == "layered":
        size = n_bits
        calculator = lambda molecule: bit_vector_to_numpy(
            Chem.LayeredFingerprint(molecule, fpSize=size), size
        )
    elif representation == "avalon":
        try:
            from rdkit.Avalon import pyAvalonTools
        except ImportError as exc:
            raise RuntimeError("This RDKit build does not include Avalon support") from exc
        size = n_bits
        calculator = lambda molecule: bit_vector_to_numpy(
            pyAvalonTools.GetAvalonFP(molecule, nBits=size), size
        )
    else:
        raise ValueError(f"Unsupported fingerprint representation: {representation}")

    names = [f"{representation.replace('-', '_')}_{index:04d}" for index in range(size)]
    return names, matrix_from_molecules(molecules, names, calculator)


def alvadesc_features(
    canonical: list[str | None], executable: Path, block: str, batch_size: int
) -> tuple[list[str], np.ndarray]:
    if not executable.is_file():
        raise FileNotFoundError(f"alvaDesc CLI executable not found: {executable}")
    try:
        from alvadesccliwrapper.alvadesc import AlvaDesc
    except Exception as exc:
        raise RuntimeError(
            "alvadesccliwrapper is unavailable. Install it in the active environment and provide a licensed alvaDesc CLI."
        ) from exc

    descriptor_request: str | list[str]
    descriptor_request = (
        [name.strip() for name in block.split(",") if name.strip()]
        if "," in block
        else block.strip()
    )
    valid_positions = [index for index, value in enumerate(canonical) if value]
    if not valid_positions:
        raise ValueError("No valid SMILES are available for alvaDesc")

    names: list[str] | None = None
    batches: list[tuple[list[int], np.ndarray]] = []
    for start in range(0, len(valid_positions), batch_size):
        positions = valid_positions[start : start + batch_size]
        smiles = [canonical[index] for index in positions]
        client = AlvaDesc(str(executable))
        client.set_input_SMILES(smiles)
        if not client.calculate_descriptors(descriptor_request):
            raise RuntimeError(f"alvaDesc failed: {client.get_error()}")
        batch_names = [str(name) for name in client.get_output_descriptors()]
        values = np.asarray(client.get_output(), dtype=np.float64)
        if values.ndim == 1:
            values = values.reshape(1, -1)
        if values.shape != (len(positions), len(batch_names)):
            raise RuntimeError(
                f"alvaDesc returned shape {values.shape}; expected {(len(positions), len(batch_names))}"
            )
        if names is None:
            names = batch_names
        elif batch_names != names:
            raise RuntimeError("alvaDesc returned inconsistent descriptor columns across batches")
        batches.append((positions, values))

    assert names is not None
    matrix = np.full((len(canonical), len(names)), np.nan, dtype=np.float64)
    for positions, values in batches:
        matrix[positions, :] = values
    matrix[~np.isfinite(matrix)] = np.nan
    return names, matrix


def feature_block(
    series: pd.Series, args: argparse.Namespace
) -> tuple[list[str], np.ndarray, list[str | None], list[int]]:
    molecules, canonical, invalid_rows = prepare_molecules(series)
    if args.representation == "rdkit-descriptors":
        names, matrix = rdkit_descriptor_features(molecules)
    elif args.representation == "rdkit-descriptors-3d":
        names, matrix = rdkit_3d_descriptor_features(
            molecules, args.conformer_seed, args.optimize_3d
        )
    elif args.representation == "rdkit-descriptors-all":
        names_2d, matrix_2d = rdkit_descriptor_features(molecules)
        names_3d, matrix_3d = rdkit_3d_descriptor_features(
            molecules, args.conformer_seed, args.optimize_3d
        )
        names = [f"2D__{name}" for name in names_2d] + [f"3D__{name}" for name in names_3d]
        matrix = np.concatenate([matrix_2d, matrix_3d], axis=1)
    elif args.representation == "alvadesc":
        if not args.alvadesc_exe:
            raise ValueError("--alvadesc-exe is required for --representation alvadesc")
        names, matrix = alvadesc_features(
            canonical, Path(args.alvadesc_exe).expanduser(), args.alvadesc_block, args.batch_size
        )
    else:
        names, matrix = fingerprint_features(
            molecules, args.representation, args.radius, args.n_bits
        )
    return names, matrix, canonical, invalid_rows


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not math.isfinite(float(value)) else float(value)
    return value


def main() -> int:
    args = parse_args()
    if args.n_bits <= 0 or args.radius < 0 or args.batch_size <= 0:
        raise ValueError("--n-bits and --batch-size must be positive; --radius cannot be negative")
    input_path = Path(args.input).expanduser()
    output_path = Path(args.output).expanduser()
    if not input_path.is_file():
        raise FileNotFoundError(input_path)
    frame = read_table(input_path, args.sheet)
    smiles_cols = normalize_list(args.smiles_cols)
    missing = [column for column in smiles_cols if column not in frame.columns]
    if missing:
        raise KeyError(f"SMILES columns not found: {missing}")

    try:
        from rdkit import rdBase
    except ImportError as exc:
        raise RuntimeError(
            "RDKit is required for molecular parsing and feature calculation. Install RDKit in the active environment."
        ) from exc

    result = frame.copy()
    feature_columns: list[str] = []
    invalid_by_column: dict[str, list[int]] = {}
    canonical_sha256_by_column: dict[str, str] = {}
    valid_canonical_count_by_column: dict[str, int] = {}
    invalid_union: set[int] = set()

    for column in smiles_cols:
        names, matrix, canonical, invalid_rows = feature_block(frame[column], args)
        prefix = f"{column}__{args.representation.replace('-', '_')}"
        prefixed_names = [f"{prefix}__{name}" for name in names]
        if args.invalid_policy == "zero":
            matrix = np.nan_to_num(matrix, nan=0.0, posinf=0.0, neginf=0.0)
        block = pd.DataFrame(matrix, columns=prefixed_names, index=frame.index)
        result = pd.concat([result, block], axis=1)
        feature_columns.extend(prefixed_names)
        invalid_by_column[column] = invalid_rows
        canonical_payload = "\n".join(value or "" for value in canonical).encode("utf-8")
        canonical_sha256_by_column[column] = hashlib.sha256(canonical_payload).hexdigest()
        valid_canonical_count_by_column[column] = sum(value is not None for value in canonical)
        invalid_union.update(invalid_rows)
        print(
            f"{column}: {len(names)} features; {len(frame) - len(invalid_rows)}/{len(frame)} valid SMILES"
        )

    dropped_original_indices: list[Any] = []
    if args.invalid_policy == "drop" and invalid_union:
        dropped_original_indices = result.index[list(sorted(invalid_union))].tolist()
        result = result.drop(index=dropped_original_indices)

    write_table(result, output_path)
    manifest = {
        "input": str(input_path.resolve()),
        "input_sha256": sha256_file(input_path),
        "output": str(output_path.resolve()),
        "representation": args.representation,
        "smiles_columns": smiles_cols,
        "parameters": {
            "radius": args.radius,
            "n_bits": args.n_bits,
            "conformer_seed": args.conformer_seed
            if args.representation in {"rdkit-descriptors-3d", "rdkit-descriptors-all"}
            else None,
            "3d_optimize": args.optimize_3d
            if args.representation in {"rdkit-descriptors-3d", "rdkit-descriptors-all"}
            else None,
            "invalid_policy": args.invalid_policy,
            "alvadesc_executable": str(Path(args.alvadesc_exe).resolve())
            if args.alvadesc_exe
            else None,
            "alvadesc_block": args.alvadesc_block if args.representation == "alvadesc" else None,
            "batch_size": args.batch_size if args.representation == "alvadesc" else None,
        },
        "versions": {
            "python": platform.python_version(),
            "pandas": pd.__version__,
            "numpy": np.__version__,
            "rdkit": rdBase.rdkitVersion,
        },
        "rows_input": len(frame),
        "rows_output": len(result),
        "generated_feature_count": len(feature_columns),
        "feature_columns": feature_columns,
        "invalid_row_positions_by_smiles_column": invalid_by_column,
        "dropped_original_indices": dropped_original_indices,
        "valid_canonical_count_by_smiles_column": valid_canonical_count_by_column,
        "canonical_smiles_sha256_by_column": canonical_sha256_by_column,
        "warnings": [
            "Descriptor definitions are version-specific; preserve this manifest.",
            "Imputation and learned feature filtering must be fitted inside training folds.",
        ],
    }
    if args.representation == "alvadesc":
        manifest["warnings"].append(
            "alvaDesc is commercial software; this run requires a separate valid installation and license."
        )
    manifest_path = output_path.with_suffix(output_path.suffix + ".manifest.json")
    manifest_path.write_text(
        json.dumps(json_safe(manifest), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Wrote {output_path} with {len(result)} rows and {len(feature_columns)} generated features")
    print(f"Wrote {manifest_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise

#!/usr/bin/env python3
"""Audit tabular or molecular datasets before machine learning."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create JSON and Markdown audits for CSV/TSV/XLSX datasets."
    )
    parser.add_argument("--input", required=True, help="Input CSV, TSV, XLS, or XLSX file")
    parser.add_argument("--target", required=True, help="Target column")
    parser.add_argument(
        "--task", choices=["auto", "regression", "classification"], default="auto"
    )
    parser.add_argument("--id-col", help="Optional unique row identifier")
    parser.add_argument("--group-col", help="Optional leakage-safe grouping column")
    parser.add_argument(
        "--smiles-cols",
        nargs="*",
        default=[],
        help="One or more SMILES columns; comma-separated input is also accepted",
    )
    parser.add_argument("--sheet", default=0, help="Excel sheet name or zero-based index")
    parser.add_argument("--output-dir", required=True, help="Directory for audit artifacts")
    return parser.parse_args()


def normalize_list(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        result.extend(part.strip() for part in value.split(",") if part.strip())
    return list(dict.fromkeys(result))


def read_table(path: Path, sheet: str | int = 0) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    if suffix in {".xls", ".xlsx", ".xlsm"}:
        parsed_sheet: str | int = int(sheet) if str(sheet).isdigit() else sheet
        return pd.read_excel(path, sheet_name=parsed_sheet)
    raise ValueError(f"Unsupported input format: {suffix}")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def infer_task(target: pd.Series) -> str:
    clean = target.dropna()
    unique_count = clean.nunique()
    if not pd.api.types.is_numeric_dtype(clean):
        return "classification"
    threshold = max(10, int(math.sqrt(max(len(clean), 1))))
    if unique_count <= threshold and unique_count <= 20:
        return "classification"
    return "regression"


def safe_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): safe_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe_value(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if pd.isna(value):
        return None
    return value


def normalized_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", name.lower())


def target_summary(target: pd.Series, task: str) -> dict[str, Any]:
    clean = target.dropna()
    if task == "regression":
        numeric = pd.to_numeric(clean, errors="coerce")
        return {
            "count": int(numeric.notna().sum()),
            "non_numeric_after_conversion": int(numeric.isna().sum()),
            "mean": numeric.mean(),
            "std": numeric.std(),
            "min": numeric.min(),
            "q25": numeric.quantile(0.25),
            "median": numeric.median(),
            "q75": numeric.quantile(0.75),
            "max": numeric.max(),
        }
    counts = clean.astype(str).value_counts(dropna=False)
    return {
        "classes": int(len(counts)),
        "class_counts": counts.to_dict(),
        "minority_fraction": counts.min() / counts.sum() if len(counts) else None,
    }


def smiles_summary(frame: pd.DataFrame, columns: list[str]) -> tuple[dict[str, Any], str | None]:
    if not columns:
        return {}, None
    try:
        from rdkit import Chem, rdBase
    except ImportError:
        return {
            col: {"status": "not_checked", "reason": "RDKit is not installed"}
            for col in columns
        }, None

    summaries: dict[str, Any] = {}
    for column in columns:
        series = frame[column]
        nonempty = series.dropna().astype(str).str.strip()
        nonempty = nonempty[nonempty != ""]
        invalid_examples: list[str] = []
        canonical: list[str] = []
        for text in nonempty:
            molecule = Chem.MolFromSmiles(text)
            if molecule is None:
                if len(invalid_examples) < 10:
                    invalid_examples.append(text)
            else:
                canonical.append(Chem.MolToSmiles(molecule, canonical=True))
        summaries[column] = {
            "nonempty": int(len(nonempty)),
            "valid": int(len(canonical)),
            "invalid": int(len(nonempty) - len(canonical)),
            "unique_canonical": int(len(set(canonical))),
            "duplicate_canonical_entries": int(len(canonical) - len(set(canonical))),
            "invalid_examples": invalid_examples,
        }
    return summaries, rdBase.rdkitVersion


def leakage_warnings(frame: pd.DataFrame, target_col: str, excluded: set[str]) -> list[dict[str, str]]:
    warnings: list[dict[str, str]] = []
    target_key = normalized_name(target_col)
    target = pd.to_numeric(frame[target_col], errors="coerce")
    for column in frame.columns:
        if column in excluded or column == target_col:
            continue
        key = normalized_name(str(column))
        if key == target_key or (len(target_key) >= 3 and target_key in key):
            warnings.append(
                {
                    "column": str(column),
                    "reason": "Column name contains or reproduces the target name",
                }
            )
        if pd.api.types.is_numeric_dtype(frame[column]) and target.notna().sum() >= 3:
            feature = pd.to_numeric(frame[column], errors="coerce")
            valid = feature.notna() & target.notna()
            if valid.sum() >= 3 and feature[valid].nunique() > 1:
                corr = feature[valid].corr(target[valid])
                if pd.notna(corr) and abs(corr) >= 0.999:
                    warnings.append(
                        {
                            "column": str(column),
                            "reason": f"Near-perfect Pearson correlation with target ({corr:.6f})",
                        }
                    )
    return warnings


def build_report(args: argparse.Namespace, frame: pd.DataFrame, input_path: Path) -> dict[str, Any]:
    required = [args.target]
    optional = [args.id_col, args.group_col] + normalize_list(args.smiles_cols)
    missing = [col for col in required + [c for c in optional if c] if col not in frame.columns]
    if missing:
        raise KeyError(f"Columns not found: {missing}")

    task = infer_task(frame[args.target]) if args.task == "auto" else args.task
    numeric_cols = frame.select_dtypes(include=np.number).columns.tolist()
    categorical_cols = [col for col in frame.columns if col not in numeric_cols]
    missing_rows = frame.isna().any(axis=1)
    missingness = frame.isna().mean().sort_values(ascending=False)
    smiles_cols = normalize_list(args.smiles_cols)
    smiles, rdkit_version = smiles_summary(frame, smiles_cols)

    constant_columns = [str(col) for col in frame.columns if frame[col].nunique(dropna=True) <= 1]
    near_unique = [
        str(col)
        for col in frame.columns
        if len(frame) and frame[col].nunique(dropna=True) / len(frame) >= 0.98
    ]
    excluded = {c for c in [args.id_col, args.group_col] + smiles_cols if c}
    warnings = leakage_warnings(frame, args.target, excluded)
    if args.group_col is None:
        warnings.append(
            {
                "column": "",
                "reason": "No group column supplied; random CV may leak related systems",
            }
        )
    if frame.duplicated().any():
        warnings.append(
            {
                "column": "",
                "reason": "Exact duplicate rows exist and should be resolved before splitting",
            }
        )

    report: dict[str, Any] = {
        "input": {
            "path": str(input_path.resolve()),
            "sha256": sha256_file(input_path),
            "bytes": input_path.stat().st_size,
        },
        "shape": {"rows": len(frame), "columns": len(frame.columns)},
        "columns": [str(c) for c in frame.columns],
        "dtypes": {str(k): str(v) for k, v in frame.dtypes.items()},
        "numeric_columns": numeric_cols,
        "categorical_columns": categorical_cols,
        "target": {
            "column": args.target,
            "task": task,
            "missing": int(frame[args.target].isna().sum()),
            "summary": target_summary(frame[args.target], task),
        },
        "missingness": {
            "rows_with_any_missing": int(missing_rows.sum()),
            "by_column": {str(k): v for k, v in missingness.items() if v > 0},
        },
        "duplicates": {
            "exact_duplicate_rows": int(frame.duplicated().sum()),
            "duplicate_ids": int(frame[args.id_col].duplicated().sum()) if args.id_col else None,
        },
        "groups": (
            {
                "column": args.group_col,
                "count": int(frame[args.group_col].nunique(dropna=True)),
                "missing": int(frame[args.group_col].isna().sum()),
                "largest_group": int(frame[args.group_col].value_counts().max())
                if frame[args.group_col].notna().any()
                else 0,
            }
            if args.group_col
            else None
        ),
        "constant_columns": constant_columns,
        "near_unique_columns": near_unique,
        "smiles": smiles,
        "rdkit_version": rdkit_version,
        "leakage_warnings": warnings,
    }
    return safe_value(report)


def markdown_report(report: dict[str, Any]) -> str:
    shape = report["shape"]
    target = report["target"]
    lines = [
        "# Dataset audit",
        "",
        f"- Input: `{report['input']['path']}`",
        f"- SHA-256: `{report['input']['sha256']}`",
        f"- Shape: {shape['rows']} rows × {shape['columns']} columns",
        f"- Target: `{target['column']}` ({target['task']})",
        f"- Missing target rows: {target['missing']}",
        f"- Exact duplicate rows: {report['duplicates']['exact_duplicate_rows']}",
        "",
        "## Validation structure",
        "",
    ]
    if report["groups"]:
        group = report["groups"]
        lines.append(
            f"Group column `{group['column']}` has {group['count']} groups; largest group has {group['largest_group']} rows."
        )
    else:
        lines.append("No group column was supplied. Confirm that rows are genuinely independent before random cross-validation.")

    lines.extend(["", "## Missingness", ""])
    missingness = report["missingness"]["by_column"]
    if missingness:
        lines.append("| Column | Missing fraction |")
        lines.append("|---|---:|")
        for column, fraction in list(missingness.items())[:30]:
            lines.append(f"| {column} | {fraction:.3f} |")
    else:
        lines.append("No missing values detected.")

    if report["smiles"]:
        lines.extend(["", "## Molecular structures", "", "| Column | Nonempty | Valid | Invalid | Unique canonical |", "|---|---:|---:|---:|---:|"])
        for column, item in report["smiles"].items():
            if item.get("status") == "not_checked":
                lines.append(f"| {column} | — | — | — | — |")
            else:
                lines.append(
                    f"| {column} | {item['nonempty']} | {item['valid']} | {item['invalid']} | {item['unique_canonical']} |"
                )

    lines.extend(["", "## Leakage and quality warnings", ""])
    warnings = report["leakage_warnings"]
    if warnings:
        for item in warnings:
            label = f"`{item['column']}`: " if item["column"] else ""
            lines.append(f"- {label}{item['reason']}")
    else:
        lines.append("No automated leakage warnings were triggered. This is not proof that leakage is absent.")

    lines.extend(["", "## Target summary", "", "```json", json.dumps(target["summary"], ensure_ascii=False, indent=2), "```", ""])
    return "\n".join(lines)


def main() -> int:
    args = parse_args()
    input_path = Path(args.input).expanduser()
    if not input_path.is_file():
        raise FileNotFoundError(input_path)
    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    frame = read_table(input_path, args.sheet)
    report = build_report(args, frame, input_path)

    json_path = output_dir / "data_audit.json"
    markdown_path = output_dir / "data_audit.md"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    markdown_path.write_text(markdown_report(report), encoding="utf-8")
    print(f"Wrote {json_path}")
    print(f"Wrote {markdown_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise

---
name: frepml-research-agent
description: Build, audit, compare, and report reproducible machine-learning workflows for tabular, materials, formulation, and molecular datasets. Use when Codex needs to inspect CSV/XLSX data, prevent leakage, choose molecular fingerprints or RDKit descriptors, optionally use licensed alvaDesc descriptors, benchmark classical models or GNNs, validate with grouped/scaffold-aware splits, assess applicability, or package a trained model and research report.
---

# FREPML Research Agent

Turn a user dataset and scientific question into an auditable ML workflow. Prefer reliable out-of-fold evidence over a visually impressive single split. Treat molecular representation, validation design, and applicability domain as explicit experimental choices.

## Start Here

1. Identify the dataset, target column, task type, row identity, molecular columns, grouping variables, and intended prediction use.
2. Read [validation-protocol.md](references/validation-protocol.md) before designing any split or interpreting metrics.
3. If molecular structures are present, read [molecular-representations.md](references/molecular-representations.md) before choosing features.
4. Run `scripts/audit_dataset.py` before modeling. Inspect both its JSON and Markdown outputs.
5. Create molecular features with `scripts/compute_molecular_features.py`, or use `scripts/run_gnn_baseline.py` for an optional graph benchmark.
6. Run `scripts/run_tabular_benchmark.py` on numeric formulation, process, descriptor, or fingerprint features.
7. Check every artifact against [output-contract.md](references/output-contract.md) before making conclusions.

Do not silently guess a target, ID, or grouping variable when several plausible choices exist. If the dataset itself resolves the ambiguity, proceed and record the choice; otherwise ask one concise question.

## Representation Decision

Choose one or more representations and compare them under the same folds:

- Start with `rdkit-descriptors` for all descriptors in RDKit's registered 2D collection when interpretability, low sample size, or physicochemical signal matters. Use `rdkit-descriptors-3d` for the standard conformer-dependent 3D families, or `rdkit-descriptors-all` for both sets.
- Start with `morgan-bit` for a strong general structural fingerprint baseline. Add `morgan-count` when motif multiplicity may matter.
- Add `rdkit-fingerprint`, `maccs`, `atom-pair`, `topological-torsion`, `pattern`, or `layered` when they match the chemical hypothesis or a fair representation comparison is requested.
- Use `avalon` only when the installed RDKit build exposes Avalon support.
- Use `alvadesc` only when the user has a working alvaDesc installation and license. Ask for or discover the executable path. Never imply that alvaDesc is free or bundled.
- Use `gnn` as a separately validated comparison when there is enough data or graph topology is central. On small datasets, always retain descriptor/fingerprint tabular baselines.

If alvaDesc is requested but unavailable, preserve the requested settings in the manifest, report the missing dependency or license clearly, and offer `rdkit-descriptors` plus Morgan as the open-source fallback. Do not fabricate or approximate alvaDesc columns.

For multiple molecular components, pass every SMILES column. Prefix features by component, then retain formulation ratios and process variables as ordinary tabular features. Do not concatenate component SMILES into a chemically false molecule.

## Commands

Use the Python interpreter from the active scientific environment when possible.

Audit a dataset:

```powershell
python scripts/audit_dataset.py --input data.xlsx --target LOI --smiles-cols EP_SMILES FR_SMILES --group-col paper_id --output-dir outputs/audit
```

Compute open-source descriptors or fingerprints:

```powershell
python scripts/compute_molecular_features.py --input data.xlsx --output outputs/morgan.csv --smiles-cols EP_SMILES FR_SMILES --representation morgan-bit --radius 2 --n-bits 2048
python scripts/compute_molecular_features.py --input data.xlsx --output outputs/rdkit.csv --smiles-cols EP_SMILES FR_SMILES --representation rdkit-descriptors
python scripts/compute_molecular_features.py --input data.xlsx --output outputs/rdkit_all.csv --smiles-cols EP_SMILES FR_SMILES --representation rdkit-descriptors-all --conformer-seed 42 --3d-optimize mmff
```

Compute licensed alvaDesc descriptors:

```powershell
python scripts/compute_molecular_features.py --input data.xlsx --output outputs/alvadesc.csv --smiles-cols EP_SMILES FR_SMILES --representation alvadesc --alvadesc-exe "C:\Program Files\Alvascience\alvaDesc\alvaDescCLI.exe" --alvadesc-block ALL
```

Run classical tabular benchmarks:

```powershell
python scripts/run_tabular_benchmark.py --input outputs/morgan.csv --target LOI --task regression --group-col paper_id --exclude-cols sample_id --output-dir outputs/benchmark --folds 5
```

Run an optional graph benchmark:

```powershell
python scripts/run_gnn_baseline.py --input data.xlsx --target LOI --task regression --smiles-cols EP_SMILES FR_SMILES --numeric-cols FR_loading cure_temperature --group-col paper_id --architecture gin --output-dir outputs/gnn
```

Use `--help` on each script for the full option set. Install optional dependencies only with the user's permission when they are missing.

## Validation Rules

- Split by the unit that could leak: paper, formulation family, polymer system, molecule, scaffold, batch, patient, site, or time.
- Put imputation, scaling, variance filtering, feature selection, and tuning inside each training fold.
- Report pooled out-of-fold predictions and fold dispersion. Never select the best-looking fold as the headline result.
- Deduplicate before splitting, and keep alternate measurements of the same system together.
- Keep a final external set untouched when one exists. Do not call a reused tuning set external validation.
- For molecular extrapolation, assess similarity or distance to training data and label out-of-domain predictions.
- Compare representations using identical rows, folds, target handling, and metrics.
- Treat randomized SMILES as alternate encodings, not new independent molecules.
- Separate model selection results from the full-data refit artifact.

## Completion Criteria

Deliver the artifacts defined in [output-contract.md](references/output-contract.md). State what was run, what was unavailable, which split protected against leakage, what the out-of-fold metrics show, and where the model should not be trusted. Do not claim a method is superior unless paired comparisons under the same folds support the statement.

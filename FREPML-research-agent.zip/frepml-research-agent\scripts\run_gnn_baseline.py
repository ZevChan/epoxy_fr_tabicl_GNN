#!/usr/bin/env python3
"""Run a fixed, leakage-aware PyTorch Geometric graph baseline."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import random
import sys
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    roc_auc_score,
)
from sklearn.model_selection import GroupKFold, KFold, StratifiedKFold
from sklearn.preprocessing import LabelEncoder, StandardScaler


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare a fixed GCN, GraphSAGE, GAT, or GIN baseline using OOF predictions."
    )
    parser.add_argument("--input", required=True)
    parser.add_argument("--target", required=True)
    parser.add_argument(
        "--task", choices=["auto", "regression", "classification"], default="auto"
    )
    parser.add_argument("--smiles-cols", nargs="+", required=True)
    parser.add_argument(
        "--numeric-cols",
        nargs="*",
        default=[],
        help="Numeric formulation/process columns; default uses every eligible numeric column",
    )
    parser.add_argument("--exclude-cols", nargs="*", default=[])
    parser.add_argument("--id-col")
    parser.add_argument("--group-col")
    parser.add_argument("--scaffold-smiles-col")
    parser.add_argument(
        "--invalid-policy",
        choices=["allow-partial", "drop-row"],
        default="allow-partial",
        help="Allow missing components or require every SMILES role to parse",
    )
    parser.add_argument("--architecture", choices=["gcn", "sage", "gat", "gin"], default="gin")
    parser.add_argument("--hidden-dim", type=int, default=128)
    parser.add_argument("--layers", type=int, default=3)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-5)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--sheet", default=0)
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args()


def normalize_list(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        result.extend(part.strip() for part in value.split(",") if part.strip())
    return list(dict.fromkeys(result))


def read_table(path: Path, sheet: str | int = 0) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    if suffix in {".xls", ".xlsx", ".xlsm"}:
        parsed_sheet: str | int = int(sheet) if str(sheet).isdigit() else sheet
        return pd.read_excel(path, sheet_name=parsed_sheet)
    raise ValueError(f"Unsupported input format: {suffix}")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def infer_task(target: pd.Series) -> str:
    clean = target.dropna()
    unique_count = clean.nunique()
    if not pd.api.types.is_numeric_dtype(clean):
        return "classification"
    threshold = max(10, int(math.sqrt(max(len(clean), 1))))
    return "classification" if unique_count <= min(20, threshold) else "regression"


def require_graph_stack() -> dict[str, Any]:
    try:
        import torch
        import torch.nn.functional as functional
        import torch_geometric
        from torch import nn
        from torch_geometric.data import Data
        from torch_geometric.loader import DataLoader
        from torch_geometric.nn import (
            GATConv,
            GCNConv,
            GINConv,
            SAGEConv,
            global_mean_pool,
        )
    except ImportError as exc:
        raise RuntimeError(
            "GNN mode requires PyTorch and PyTorch Geometric in the active environment. "
            "Install versions appropriate for the machine's CPU/CUDA setup, then rerun."
        ) from exc
    try:
        import rdkit
        from rdkit import Chem
    except ImportError as exc:
        raise RuntimeError("GNN mode requires RDKit") from exc
    return locals()


def set_seed(stack: dict[str, Any], seed: int) -> None:
    torch = stack["torch"]
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def atom_features(atom: Any, role: int, roles: int) -> list[float]:
    hybridizations = ["SP", "SP2", "SP3", "SP3D", "SP3D2"]
    degree = min(int(atom.GetDegree()), 6)
    hydrogens = min(int(atom.GetTotalNumHs()), 5)
    values = [float(atom.GetAtomicNum()) / 100.0]
    values.extend(float(degree == value) for value in range(7))
    values.append(float(atom.GetFormalCharge()) / 4.0)
    hybridization = str(atom.GetHybridization())
    values.extend(float(hybridization == value) for value in hybridizations)
    values.append(float(hybridization not in hybridizations))
    values.extend([float(atom.GetIsAromatic()), float(atom.IsInRing())])
    values.extend(float(hydrogens == value) for value in range(6))
    values.extend(float(role == value) for value in range(roles))
    return values


def row_to_graph(
    stack: dict[str, Any], row: pd.Series, smiles_cols: list[str], invalid_policy: str
) -> tuple[Any | None, list[int]]:
    torch, Data, Chem = stack["torch"], stack["Data"], stack["Chem"]
    node_features: list[list[float]] = []
    edges: list[tuple[int, int]] = []
    presence: list[int] = []
    offset = 0
    invalid_roles: list[int] = []
    for role, column in enumerate(smiles_cols):
        value = row[column]
        molecule = None if pd.isna(value) or not str(value).strip() else Chem.MolFromSmiles(str(value).strip())
        if molecule is None:
            presence.append(0)
            invalid_roles.append(role)
            continue
        presence.append(1)
        for atom in molecule.GetAtoms():
            node_features.append(atom_features(atom, role, len(smiles_cols)))
        for bond in molecule.GetBonds():
            begin = offset + bond.GetBeginAtomIdx()
            end = offset + bond.GetEndAtomIdx()
            edges.extend([(begin, end), (end, begin)])
        offset += molecule.GetNumAtoms()
    if not node_features or (invalid_policy == "drop-row" and invalid_roles):
        return None, invalid_roles
    edge_index = (
        torch.tensor(edges, dtype=torch.long).t().contiguous()
        if edges
        else torch.empty((2, 0), dtype=torch.long)
    )
    graph = Data(
        x=torch.tensor(node_features, dtype=torch.float32),
        edge_index=edge_index,
        component_presence=torch.tensor([presence], dtype=torch.float32),
    )
    return graph, invalid_roles


def scaffold_groups(stack: dict[str, Any], smiles: pd.Series) -> pd.Series:
    Chem = stack["Chem"]
    from rdkit.Chem.Scaffolds import MurckoScaffold

    result: list[str] = []
    for position, value in enumerate(smiles):
        molecule = None if pd.isna(value) else Chem.MolFromSmiles(str(value))
        if molecule is None:
            result.append(f"__invalid_{position}")
        else:
            scaffold = MurckoScaffold.MurckoScaffoldSmiles(mol=molecule)
            result.append(scaffold or Chem.MolToSmiles(molecule, canonical=True))
    return pd.Series(result, index=smiles.index)


def make_splits(
    y: np.ndarray, task: str, groups: pd.Series | None, folds: int, seed: int
) -> tuple[list[tuple[np.ndarray, np.ndarray]], str]:
    if folds < 2:
        raise ValueError("--folds must be at least 2")
    if groups is not None:
        if groups.nunique() < folds:
            raise ValueError(f"Only {groups.nunique()} groups are available for {folds} folds")
        if task == "classification":
            try:
                from sklearn.model_selection import StratifiedGroupKFold

                splitter = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=seed)
                return list(splitter.split(np.zeros(len(y)), y, groups)), "StratifiedGroupKFold"
            except (ImportError, ValueError):
                pass
        splitter = GroupKFold(n_splits=folds)
        return list(splitter.split(np.zeros(len(y)), y, groups)), "GroupKFold"
    if task == "classification":
        counts = np.bincount(y.astype(int))
        if counts.min() < folds:
            raise ValueError(f"Minority class has {counts.min()} rows, fewer than {folds} folds")
        splitter = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
        return list(splitter.split(np.zeros(len(y)), y)), "StratifiedKFold"
    splitter = KFold(n_splits=folds, shuffle=True, random_state=seed)
    return list(splitter.split(np.zeros(len(y)))), "KFold"


def make_model_class(stack: dict[str, Any]) -> type:
    torch, nn = stack["torch"], stack["nn"]
    GCNConv, SAGEConv = stack["GCNConv"], stack["SAGEConv"]
    GATConv, GINConv = stack["GATConv"], stack["GINConv"]
    global_mean_pool = stack["global_mean_pool"]

    class MolecularGNN(nn.Module):
        def __init__(
            self,
            node_dim: int,
            tabular_dim: int,
            output_dim: int,
            architecture: str,
            hidden_dim: int,
            layers: int,
            dropout: float,
        ) -> None:
            super().__init__()
            self.architecture = architecture
            self.dropout = dropout
            self.convs = nn.ModuleList()
            input_dim = node_dim
            for _ in range(layers):
                if architecture == "gcn":
                    conv = GCNConv(input_dim, hidden_dim)
                elif architecture == "sage":
                    conv = SAGEConv(input_dim, hidden_dim)
                elif architecture == "gat":
                    if hidden_dim % 4:
                        raise ValueError("--hidden-dim must be divisible by 4 for GAT")
                    conv = GATConv(input_dim, hidden_dim // 4, heads=4, concat=True)
                else:
                    mlp = nn.Sequential(
                        nn.Linear(input_dim, hidden_dim),
                        nn.ReLU(),
                        nn.Linear(hidden_dim, hidden_dim),
                    )
                    conv = GINConv(mlp)
                self.convs.append(conv)
                input_dim = hidden_dim
            fusion_dim = hidden_dim + tabular_dim
            self.head = nn.Sequential(
                nn.Linear(fusion_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, output_dim),
            )

        def forward(self, batch: Any) -> Any:
            x = batch.x
            for conv in self.convs:
                x = conv(x, batch.edge_index)
                x = torch.relu(x)
                x = torch.dropout(x, self.dropout, train=self.training)
            pooled = global_mean_pool(x, batch.batch)
            fused = torch.cat([pooled, batch.tabular], dim=1)
            return self.head(fused)

    return MolecularGNN


def attach_fold_data(
    stack: dict[str, Any],
    base_graphs: list[Any],
    positions: np.ndarray,
    tabular: np.ndarray,
    targets: np.ndarray,
    task: str,
) -> list[Any]:
    torch = stack["torch"]
    dataset: list[Any] = []
    for local, position in enumerate(positions):
        graph = base_graphs[int(position)].clone()
        graph.tabular = torch.tensor(tabular[local : local + 1], dtype=torch.float32)
        dtype = torch.long if task == "classification" else torch.float32
        graph.y = torch.tensor([targets[local]], dtype=dtype)
        dataset.append(graph)
    return dataset


def train_model(
    stack: dict[str, Any],
    model: Any,
    dataset: list[Any],
    args: argparse.Namespace,
    device: Any,
    class_weights: np.ndarray | None = None,
) -> None:
    torch, functional, DataLoader = stack["torch"], stack["functional"], stack["DataLoader"]
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    weight_tensor = (
        torch.tensor(class_weights, dtype=torch.float32, device=device)
        if class_weights is not None
        else None
    )
    model.to(device)
    for _ in range(args.epochs):
        model.train()
        for batch in loader:
            batch = batch.to(device)
            optimizer.zero_grad(set_to_none=True)
            output = model(batch)
            if output.shape[1] == 1:
                loss = functional.mse_loss(output[:, 0], batch.y.float())
            else:
                loss = functional.cross_entropy(output, batch.y.long(), weight=weight_tensor)
            loss.backward()
            optimizer.step()


def predict_model(
    stack: dict[str, Any], model: Any, dataset: list[Any], batch_size: int, device: Any
) -> tuple[np.ndarray, np.ndarray | None]:
    torch, DataLoader = stack["torch"], stack["DataLoader"]
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    predictions: list[np.ndarray] = []
    probabilities: list[np.ndarray] = []
    model.eval()
    with torch.no_grad():
        for batch in loader:
            output = model(batch.to(device))
            if output.shape[1] == 1:
                predictions.append(output[:, 0].cpu().numpy())
            else:
                probability = torch.softmax(output, dim=1)
                predictions.append(probability.argmax(dim=1).cpu().numpy())
                probabilities.append(probability.cpu().numpy())
    pred = np.concatenate(predictions)
    prob = np.concatenate(probabilities) if probabilities else None
    return pred, prob


def regression_metrics(observed: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    return {
        "r2": float(r2_score(observed, predicted)),
        "rmse": float(mean_squared_error(observed, predicted) ** 0.5),
        "mae": float(mean_absolute_error(observed, predicted)),
    }


def classification_metrics(
    observed: np.ndarray, predicted: np.ndarray, probability: np.ndarray | None
) -> dict[str, float]:
    result = {
        "accuracy": float(accuracy_score(observed, predicted)),
        "balanced_accuracy": float(balanced_accuracy_score(observed, predicted)),
        "f1_macro": float(f1_score(observed, predicted, average="macro")),
    }
    if probability is not None and probability.shape[1] == 2 and len(np.unique(observed)) == 2:
        result["roc_auc"] = float(roc_auc_score(observed, probability[:, 1]))
    return result


def fit_preprocessor(
    train: pd.DataFrame, valid: pd.DataFrame | None = None
) -> tuple[np.ndarray, np.ndarray | None, dict[str, Any]]:
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    scaler = StandardScaler()
    train_imputed = imputer.fit_transform(train)
    train_scaled = scaler.fit_transform(train_imputed)
    valid_scaled = scaler.transform(imputer.transform(valid)) if valid is not None else None
    return train_scaled, valid_scaled, {"imputer": imputer, "scaler": scaler}


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not np.isfinite(value) else float(value)
    return value


def main() -> int:
    args = parse_args()
    if args.epochs <= 0 or args.layers <= 0 or args.hidden_dim <= 0 or args.batch_size <= 0:
        raise ValueError("Epochs, layers, hidden dimension, and batch size must be positive")
    if not 0 <= args.dropout < 1:
        raise ValueError("--dropout must be in [0, 1)")
    if args.group_col and args.scaffold_smiles_col:
        raise ValueError("Use either --group-col or --scaffold-smiles-col, not both")
    stack = require_graph_stack()
    torch = stack["torch"]
    set_seed(stack, args.seed)
    input_path = Path(args.input).expanduser()
    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    if not input_path.is_file():
        raise FileNotFoundError(input_path)
    frame = read_table(input_path, args.sheet)
    smiles_cols = normalize_list(args.smiles_cols)
    required = [args.target] + smiles_cols
    required += [column for column in [args.id_col, args.group_col, args.scaffold_smiles_col] if column]
    missing = [column for column in required if column not in frame]
    if missing:
        raise KeyError(f"Columns not found: {missing}")
    frame = frame.loc[frame[args.target].notna()].copy()
    frame["__original_index"] = frame.index

    base_graphs: list[Any] = []
    kept_rows: list[int] = []
    invalid_components: dict[str, int] = {column: 0 for column in smiles_cols}
    for row_position, (_, row) in enumerate(frame.iterrows()):
        graph, invalid_roles = row_to_graph(stack, row, smiles_cols, args.invalid_policy)
        for role in invalid_roles:
            invalid_components[smiles_cols[role]] += 1
        if graph is not None:
            base_graphs.append(graph)
            kept_rows.append(row_position)
    dropped = len(frame) - len(kept_rows)
    frame = frame.iloc[kept_rows].reset_index(drop=True)
    if len(frame) < args.folds:
        raise ValueError(f"Only {len(frame)} graph rows remain for {args.folds} folds")

    task = infer_task(frame[args.target]) if args.task == "auto" else args.task
    label_encoder: LabelEncoder | None = None
    if task == "regression":
        y = pd.to_numeric(frame[args.target], errors="coerce").to_numpy(dtype=float)
        if not np.isfinite(y).all():
            raise ValueError("Regression target contains non-numeric or infinite values")
        class_labels = None
        output_dim = 1
    else:
        label_encoder = LabelEncoder()
        y = label_encoder.fit_transform(frame[args.target].astype(str))
        class_labels = label_encoder.classes_.tolist()
        output_dim = len(class_labels)
        if output_dim < 2:
            raise ValueError("Classification requires at least two classes")

    excluded = set(normalize_list(args.exclude_cols) + smiles_cols)
    excluded.update(
        column
        for column in [args.target, args.id_col, args.group_col, args.scaffold_smiles_col, "__original_index"]
        if column
    )
    numeric_cols = normalize_list(args.numeric_cols)
    if not numeric_cols:
        numeric_cols = [
            str(column)
            for column in frame.select_dtypes(include=np.number).columns
            if column not in excluded
        ]
    missing_numeric = [column for column in numeric_cols if column not in frame]
    if missing_numeric:
        raise KeyError(f"Numeric columns not found: {missing_numeric}")
    numeric_frame = frame[numeric_cols].replace([np.inf, -np.inf], np.nan).copy()
    presence = np.vstack([graph.component_presence.numpy()[0] for graph in base_graphs])
    presence_cols = [f"component_present__{column}" for column in smiles_cols]
    for index, column in enumerate(presence_cols):
        numeric_frame[column] = presence[:, index]
    tabular_cols = numeric_cols + presence_cols

    if args.group_col:
        groups = frame[args.group_col].astype(object).copy()
        for position in np.flatnonzero(groups.isna().to_numpy()):
            groups.iloc[position] = f"__missing_group_{position}"
        groups = groups.astype(str)
        group_definition = args.group_col
    elif args.scaffold_smiles_col:
        groups = scaffold_groups(stack, frame[args.scaffold_smiles_col])
        group_definition = f"scaffold:{args.scaffold_smiles_col}"
    else:
        groups = None
        group_definition = None
    splits, splitter_name = make_splits(y, task, groups, args.folds, args.seed)
    for fold, (train_idx, valid_idx) in enumerate(splits):
        if groups is not None and set(groups.iloc[train_idx]) & set(groups.iloc[valid_idx]):
            raise RuntimeError(f"Group leakage detected in fold {fold}")

    device = torch.device(
        "cuda" if args.device == "auto" and torch.cuda.is_available() else args.device
        if args.device != "auto"
        else "cpu"
    )
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    ModelClass = make_model_class(stack)
    node_dim = int(base_graphs[0].x.shape[1])
    oof_pred = np.full(len(frame), np.nan)
    oof_probability = np.full((len(frame), output_dim), np.nan) if task == "classification" else None
    fold_numbers = np.full(len(frame), -1, dtype=int)
    fold_rows: list[dict[str, Any]] = []

    for fold, (train_idx, valid_idx) in enumerate(splits):
        print(f"Training {args.architecture} fold {fold + 1}/{len(splits)} on {device}")
        set_seed(stack, args.seed + fold)
        train_tab, valid_tab, _ = fit_preprocessor(
            numeric_frame.iloc[train_idx], numeric_frame.iloc[valid_idx]
        )
        if task == "regression":
            target_mean = float(y[train_idx].mean())
            target_std = float(y[train_idx].std()) or 1.0
            train_target = (y[train_idx] - target_mean) / target_std
            valid_target = (y[valid_idx] - target_mean) / target_std
            class_weights = None
        else:
            target_mean, target_std = 0.0, 1.0
            train_target, valid_target = y[train_idx], y[valid_idx]
            counts = np.bincount(y[train_idx], minlength=output_dim)
            class_weights = len(train_idx) / (output_dim * np.maximum(counts, 1))
        train_data = attach_fold_data(
            stack, base_graphs, train_idx, train_tab, train_target, task
        )
        valid_data = attach_fold_data(
            stack, base_graphs, valid_idx, valid_tab, valid_target, task
        )
        model = ModelClass(
            node_dim,
            len(tabular_cols),
            output_dim,
            args.architecture,
            args.hidden_dim,
            args.layers,
            args.dropout,
        )
        train_model(stack, model, train_data, args, device, class_weights)
        predicted, probability = predict_model(stack, model, valid_data, args.batch_size, device)
        if task == "regression":
            predicted = predicted * target_std + target_mean
            metrics = regression_metrics(y[valid_idx], predicted)
        else:
            metrics = classification_metrics(y[valid_idx], predicted.astype(int), probability)
            assert oof_probability is not None and probability is not None
            oof_probability[valid_idx] = probability
        oof_pred[valid_idx] = predicted
        fold_numbers[valid_idx] = fold
        fold_rows.append({"fold": fold, "train_rows": len(train_idx), "valid_rows": len(valid_idx), **metrics})

    pooled = (
        regression_metrics(y, oof_pred)
        if task == "regression"
        else classification_metrics(y, oof_pred.astype(int), oof_probability)
    )
    fold_metrics = pd.DataFrame(fold_rows)
    fold_metrics.to_csv(output_dir / "gnn_fold_metrics.csv", index=False)

    oof = pd.DataFrame(
        {
            "row_position": np.arange(len(frame)),
            "original_index": frame["__original_index"],
            "fold": fold_numbers,
            "observed": y,
            "predicted": oof_pred,
        }
    )
    if label_encoder is not None:
        oof["observed_label"] = label_encoder.inverse_transform(y.astype(int))
        oof["predicted_label"] = label_encoder.inverse_transform(oof_pred.astype(int))
        assert oof_probability is not None
        for class_index, label in enumerate(class_labels):
            oof[f"probability__{label}"] = oof_probability[:, class_index]
    if args.id_col:
        oof[args.id_col] = frame[args.id_col]
    if groups is not None:
        oof["validation_group"] = groups
    oof.to_csv(output_dir / "gnn_oof_predictions.csv", index=False)

    print("Training full-development-data GNN refit")
    set_seed(stack, args.seed)
    full_tab, _, full_preprocessor = fit_preprocessor(numeric_frame)
    if task == "regression":
        full_target_mean = float(y.mean())
        full_target_std = float(y.std()) or 1.0
        full_target = (y - full_target_mean) / full_target_std
        class_weights = None
    else:
        full_target_mean, full_target_std = 0.0, 1.0
        full_target = y
        counts = np.bincount(y, minlength=output_dim)
        class_weights = len(y) / (output_dim * np.maximum(counts, 1))
    positions = np.arange(len(frame))
    full_data = attach_fold_data(stack, base_graphs, positions, full_tab, full_target, task)
    final_model = ModelClass(
        node_dim,
        len(tabular_cols),
        output_dim,
        args.architecture,
        args.hidden_dim,
        args.layers,
        args.dropout,
    )
    train_model(stack, final_model, full_data, args, device, class_weights)
    checkpoint = {
        "state_dict": {key: value.detach().cpu() for key, value in final_model.state_dict().items()},
        "model_config": {
            "node_dim": node_dim,
            "tabular_dim": len(tabular_cols),
            "output_dim": output_dim,
            "architecture": args.architecture,
            "hidden_dim": args.hidden_dim,
            "layers": args.layers,
            "dropout": args.dropout,
        },
        "smiles_columns": smiles_cols,
        "tabular_columns": tabular_cols,
        "task": task,
        "class_labels": class_labels,
        "target_mean": full_target_mean,
        "target_std": full_target_std,
        "status": "full-development-data refit",
    }
    torch.save(checkpoint, output_dir / "gnn_full_refit.pt")
    joblib.dump(full_preprocessor, output_dir / "gnn_tabular_preprocessor.joblib")

    manifest = {
        "input": str(input_path.resolve()),
        "input_sha256": sha256_file(input_path),
        "task": task,
        "target": args.target,
        "class_labels": class_labels,
        "smiles_columns": smiles_cols,
        "numeric_columns": numeric_cols,
        "tabular_columns": tabular_cols,
        "rows_after_target_filter": len(frame) + dropped,
        "rows_modeled": len(frame),
        "rows_dropped_for_invalid_structures": dropped,
        "invalid_or_missing_component_counts": invalid_components,
        "invalid_policy": args.invalid_policy,
        "splitter": splitter_name,
        "group_definition": group_definition,
        "folds": args.folds,
        "seed": args.seed,
        "device": str(device),
        "architecture": args.architecture,
        "hyperparameters": {
            "hidden_dim": args.hidden_dim,
            "layers": args.layers,
            "dropout": args.dropout,
            "epochs": args.epochs,
            "batch_size": args.batch_size,
            "learning_rate": args.learning_rate,
            "weight_decay": args.weight_decay,
        },
        "pooled_oof_metrics": pooled,
        "saved_model_status": "full-development-data refit",
        "versions": {
            "python": platform.python_version(),
            "torch": torch.__version__,
            "torch_geometric": stack["torch_geometric"].__version__,
            "rdkit": stack["rdkit"].__version__,
            "numpy": np.__version__,
            "pandas": pd.__version__,
        },
        "warnings": [
            "Outer validation folds were not used for early stopping; a fixed epoch count was used.",
            "This GNN should be compared with descriptor and fingerprint baselines on identical folds.",
            "The saved checkpoint is a full-data refit, not independent validation evidence.",
        ],
    }
    (output_dir / "gnn_manifest.json").write_text(
        json.dumps(json_safe(manifest), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    primary = "r2" if task == "regression" else "roc_auc" if "roc_auc" in pooled else "balanced_accuracy"
    report = [
        "# GNN benchmark report",
        "",
        f"- Architecture: {args.architecture}",
        f"- Rows modeled: {len(frame)}",
        f"- Splitter: {splitter_name}",
        f"- Group definition: {group_definition or 'none (random row-level folds)'}",
        f"- Pooled OOF {primary}: {pooled[primary]:.4f}",
        f"- Device: {device}",
        "",
        "The saved checkpoint is a full-data refit. Compare these OOF predictions against descriptor and fingerprint models using identical fold assignments.",
        "",
        "## Fold metrics",
        "",
        "```text",
        fold_metrics.to_string(index=False),
        "```",
        "",
    ]
    (output_dir / "gnn_report.md").write_text("\n".join(report), encoding="utf-8")
    print(f"Pooled OOF metrics: {pooled}")
    print(f"Artifacts written to {output_dir}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
